# KARK Website - Node.js Deployment Guide

## Overview
Complete deployment package for the KARK (Kurtarma ve Arama Derneği) website built with Node.js, Express, and supporting both JSON file storage and MySQL database.

## Quick Start

### 1. Prerequisites
- Node.js v18+ installed
- npm or yarn package manager
- MySQL database (optional, for production)

### 2. Installation Steps

```bash
# 1. Create a new directory for your project
mkdir kark-website
cd kark-website

# 2. Copy these files to your directory:
# - starter-nodejs-site.js
# - package-starter.json (rename to package.json)
# - .env.example (rename to .env)

# 3. Rename package-starter.json to package.json
mv package-starter.json package.json

# 4. Install dependencies
npm install

# 5. Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# 6. Create data directory (for JSON storage)
mkdir data

# 7. Start the server
npm run dev  # Development mode with auto-restart
# or
npm start    # Production mode
```

## File Structure

```
kark-website/
├── starter-nodejs-site.js      # Main server file
├── package.json               # Dependencies and scripts
├── .env                       # Environment configuration
├── data/                      # JSON storage directory
│   ├── users.json
│   ├── events.json
│   ├── settings.json
│   └── ...
├── public/                    # Static files (create if needed)
└── mysql/                     # MySQL setup files
    ├── kark_complete_database_cpanel.sql
    ├── kark_api_endpoints_cpanel.sql
    └── kark_data_validation_cpanel.sql
```

## Configuration

### Environment Variables (.env)

```env
# Server
PORT=5000
NODE_ENV=production

# Storage Type
DB_TYPE=json  # or 'mysql' for database

# MySQL (if using database)
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=your_user
MYSQL_PASSWORD=your_password
MYSQL_DATABASE=your_database

# Security
SESSION_SECRET=generate-random-string-here
```

## Storage Options

### Option 1: JSON File Storage (Default)
- No database required
- Data stored in `/data` directory
- Perfect for small deployments
- Easy backup (just copy files)

### Option 2: MySQL Database
1. Import SQL files in this order:
   - `kark_complete_database_cpanel.sql`
   - `kark_api_endpoints_cpanel.sql`
   - `kark_data_validation_cpanel.sql`

2. Update `.env`:
   ```env
   DB_TYPE=mysql
   MYSQL_USER=your_cpanel_user
   MYSQL_PASSWORD=your_password
   MYSQL_DATABASE=your_cpanel_database
   ```

3. Replace table prefixes in SQL files with your cPanel prefix

## Admin Access

Default admin credentials:
- **Username:** supermanager
- **Password:** admin123

**Important:** Change these immediately after first login!

## API Endpoints

The starter file includes these basic endpoints:
- `GET /api/health` - Server health check
- `GET /api/info` - API information
- `GET /api/admin/dashboard` - Protected admin route

## Deployment Options

### 1. Local Development
```bash
npm run dev
# Server runs on http://localhost:5000
```

### 2. Production Server
```bash
NODE_ENV=production npm start
```

### 3. cPanel Deployment
1. Upload files via FTP/File Manager
2. Set up Node.js app in cPanel
3. Configure environment variables
4. Import MySQL database (if using)
5. Start the application

### 4. VPS/Cloud Deployment
```bash
# Install PM2 for process management
npm install -g pm2

# Start with PM2
pm2 start starter-nodejs-site.js --name kark-website

# Save PM2 configuration
pm2 save
pm2 startup
```

## Security Checklist

- [ ] Change default admin passwords
- [ ] Set strong SESSION_SECRET
- [ ] Enable HTTPS in production
- [ ] Configure firewall rules
- [ ] Regular backups
- [ ] Keep dependencies updated

## Troubleshooting

### Port Already in Use
```bash
# Find process using port 5000
lsof -i :5000
# Kill the process or change PORT in .env
```

### MySQL Connection Failed
- Check credentials in .env
- Verify MySQL service is running
- Check firewall allows MySQL connections

### Session Issues
- Ensure SESSION_SECRET is set
- Check cookie settings for production

## Next Steps

1. Extend the starter file with your routes
2. Add authentication middleware
3. Implement API endpoints
4. Connect frontend application
5. Set up monitoring and logging

## Support Files Included

- `CPANEL_MYSQL_SETUP.md` - Detailed cPanel setup guide
- SQL files - Complete database structure
- `.env.example` - Environment template

## License

MIT License - Feel free to modify for your needs.

---

For questions or issues, refer to the complete project documentation.