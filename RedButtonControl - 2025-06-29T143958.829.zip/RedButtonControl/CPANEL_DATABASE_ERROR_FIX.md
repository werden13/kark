# cPanel Veritabanı Hatası Çözümü

## Hata: #1044 - Access denied
```
CREATE DATABASE kark;
#1044 - Access denied for user 'cpses_ki3o30ex8i'@'localhost' to database 'kark'
```

## Neden Bu Hata Oluşuyor?
cPanel'de güvenlik nedeniyle doğrudan CREATE DATABASE komutu kullanamazsınız. Veritabanı oluşturma yetkisi sadece cPanel arayüzünden verilir.

## Doğru Çözüm:

### 1. cPanel MySQL Databases Sayfasına Gidin
- cPanel ana sayfasında "MySQL Databases" ikonunu bulun
- Tıklayın

### 2. Create New Database Bölümünde
- Metin kutusuna sadece `kark` yazın
- "Create Database" butonuna tıklayın
- Sistem otomatik olarak prefix ekleyecek (örn: `cpses_ki3o30ex8i_kark`)

### 3. Oluşan Veritabanı Adı
Sizin durumunuzda muhtemelen:
```
cpses_ki3o30ex8i_kark
```

### 4. phpMyAdmin'de SQL Dosyasını İmport Etme
1. phpMyAdmin'e gidin
2. Sol tarafta `cpses_ki3o30ex8i_kark` veritabanını tıklayın
3. Üst menüden "Import" sekmesine tıklayın
4. `kark_complete_database_cpanel_fixed.sql` dosyasını seçin
5. "Go" butonuna tıklayın

## .env Dosyanızda Kullanacağınız Bilgiler:
```
DB_TYPE=mysql
DB_HOST=localhost
DB_USER=cpses_ki3o30ex8i_karkuser
DB_PASSWORD=oluşturduğunuz_şifre
DB_NAME=cpses_ki3o30ex8i_kark
```

## Önemli:
- Asla phpMyAdmin'de CREATE DATABASE yazmayın
- Her zaman cPanel MySQL Databases arayüzünü kullanın
- Prefix otomatik eklenir (`cpses_ki3o30ex8i_`)