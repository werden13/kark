nohup node_modules/.bin/tsx server/index.ts > server.log 2>&1 &
