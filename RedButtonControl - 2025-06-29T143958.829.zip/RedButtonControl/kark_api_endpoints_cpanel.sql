-- KARK Website API Endpoints Documentation for MySQL
-- This file contains stored procedures and views for common API operations
-- Optimized for cPanel MySQL hosting

-- =====================================================
-- STORED PROCEDURES FOR COMMON OPERATIONS
-- =====================================================

DELIMITER //

-- Get user with permissions
CREATE PROCEDURE GetUserWithPermissions(IN user_id INT)
BEGIN
    SELECT 
        id, username, first_name, last_name, email, 
        is_admin, role, permissions, created_at
    FROM kark_users 
    WHERE id = user_id AND role != 'banned';
END //

-- Get active events
CREATE PROCEDURE GetActiveEvents(IN limit_count INT)
BEGIN
    SELECT 
        id, title, description, date, location, 
        category, image_path, created_at
    FROM kark_events 
    WHERE date >= CURDATE()
    ORDER BY date ASC
    LIMIT limit_count;
END //

-- Get featured activities
CREATE PROCEDURE GetFeaturedActivities()
BEGIN
    SELECT 
        id, title, description, image_url, category, 
        date, location, created_at
    FROM kark_activities 
    WHERE is_featured = 1 AND is_active = 1
    ORDER BY created_at DESC;
END //

-- Get public settings
CREATE PROCEDURE GetPublicSettings()
BEGIN
    SELECT key, value, type
    FROM kark_settings 
    WHERE is_public = 1;
END //

-- Log admin action
CREATE PROCEDURE LogAdminAction(
    IN p_user_id INT,
    IN p_action VARCHAR(255),
    IN p_target_type VARCHAR(100),
    IN p_target_id VARCHAR(100),
    IN p_details JSON,
    IN p_ip_address VARCHAR(45),
    IN p_user_agent TEXT
)
BEGIN
    INSERT INTO kark_admin_logs 
    (user_id, action, target_type, target_id, details, ip_address, user_agent)
    VALUES 
    (p_user_id, p_action, p_target_type, p_target_id, p_details, p_ip_address, p_user_agent);
END //

DELIMITER ;

-- =====================================================
-- VIEWS FOR COMMON QUERIES
-- =====================================================

-- Active hero sliders view
CREATE VIEW active_hero_sliders AS
SELECT 
    id, title, description, image_url, button_text, 
    button_link, `order`, created_at
FROM kark_hero_sliders 
WHERE is_active = 1 
ORDER BY `order` ASC;

-- Recent activities view
CREATE VIEW recent_activities AS
SELECT 
    id, title, description, image_url, category, 
    date, location, is_featured, created_at
FROM kark_activities 
WHERE is_active = 1 
ORDER BY created_at DESC;

-- Active donation campaigns view
CREATE VIEW active_donation_campaigns AS
SELECT 
    id, title, description, goal_amount, raised_amount, 
    currency, start_date, end_date, image, is_featured
FROM kark_donation_campaigns 
WHERE is_active = 1 
    AND (start_date IS NULL OR start_date <= CURDATE())
    AND (end_date IS NULL OR end_date >= CURDATE())
ORDER BY is_featured DESC, created_at DESC;

-- Contact messages summary view
CREATE VIEW contact_messages_summary AS
SELECT 
    id, name, email, subject, status, created_at
FROM kark_contact_messages 
ORDER BY created_at DESC;

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Additional indexes for better performance
CREATE INDEX idx_events_date_category ON kark_events(date, category);
CREATE INDEX idx_activities_featured_active ON kark_activities(is_featured, is_active, created_at);
CREATE INDEX idx_media_type_album ON kark_media_items(file_type, album_id);
CREATE INDEX idx_settings_public ON kark_settings(is_public, key);
CREATE INDEX idx_admin_logs_user_action ON kark_admin_logs(user_id, action, created_at);

-- =====================================================
-- TRIGGERS FOR AUDIT TRAIL
-- =====================================================

DELIMITER //

-- Update timestamp trigger for users
CREATE TRIGGER tr_users_updated
    BEFORE UPDATE ON kark_users
    FOR EACH ROW
BEGIN
    -- You can add updated_at column if needed
    SET NEW.created_at = OLD.created_at; -- Prevent created_at from being updated
END //

-- Increment views counter for archive items
CREATE TRIGGER tr_archive_views_increment
    AFTER UPDATE ON kark_archive_items
    FOR EACH ROW
BEGIN
    -- This would be used if you add a views tracking feature
    IF NEW.views_count != OLD.views_count THEN
        -- Log view increment if needed
        INSERT INTO kark_admin_logs (user_id, action, target_type, target_id, details, created_at)
        VALUES (0, 'view_increment', 'archive_item', NEW.id, 
                JSON_OBJECT('old_count', OLD.views_count, 'new_count', NEW.views_count), 
                NOW());
    END IF;
END //

DELIMITER ;

-- =====================================================
-- SAMPLE API QUERIES
-- =====================================================

-- These are example queries that your Node.js application would use:

-- 1. Get all active events
-- SELECT * FROM kark_events WHERE date >= CURDATE() ORDER BY date ASC;

-- 2. Get user by username for login
-- SELECT id, username, password, role, permissions FROM kark_users WHERE username = ? AND role != 'banned';

-- 3. Get public settings for frontend
-- SELECT key, value FROM kark_settings WHERE is_public = 1;

-- 4. Get featured content for homepage
-- SELECT * FROM active_hero_sliders LIMIT 5;
-- SELECT * FROM recent_activities WHERE is_featured = 1 LIMIT 3;

-- 5. Create new contact message
-- INSERT INTO kark_contact_messages (name, email, phone, subject, message, ip_address, user_agent) 
-- VALUES (?, ?, ?, ?, ?, ?, ?);

-- =====================================================
-- MAINTENANCE QUERIES
-- =====================================================

-- Clean old admin logs (run monthly)
-- DELETE FROM kark_admin_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH);

-- Update campaign raised amounts (if you track donations)
-- UPDATE kark_donation_campaigns SET raised_amount = (
--     SELECT COALESCE(SUM(amount), 0) FROM donations WHERE campaign_id = kark_donation_campaigns.id
-- );

-- Archive old contact messages
-- UPDATE kark_contact_messages SET status = 'archived' 
-- WHERE status = 'read' AND created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR);

-- =====================================================
-- BACKUP RECOMMENDATIONS
-- =====================================================

-- 1. Regular database backups via cPanel
-- 2. Export important tables separately:
--    - kark_users (excluding passwords for security)
--    - kark_settings
--    - kark_activities
--    - kark_events

-- 3. Monitor table sizes and optimize regularly:
-- OPTIMIZE TABLE kark_admin_logs;
-- OPTIMIZE TABLE kark_contact_messages;

-- END OF FILE