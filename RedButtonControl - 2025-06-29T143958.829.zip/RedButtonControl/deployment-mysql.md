# MySQL Deployment Guide for KARK Website

## Prerequisites

Your KARK website is ready for MySQL deployment. Here's what you need:

### 1. MySQL Dependencies
```bash
npm install mysql2 drizzle-orm
```

### 2. Environment Variables
Set these on your hosting platform:
```
DATABASE_URL=mysql://username:password@host:port/database_name
NODE_ENV=production
```

### 3. Hosting Platform Options

#### Recommended Platforms with MySQL Support:
- **Railway**: Easy MySQL deployment
- **PlanetScale**: Serverless MySQL
- **Vercel + PlanetScale**: Frontend + Database
- **Heroku + ClearDB**: MySQL add-on
- **DigitalOcean App Platform**: MySQL managed database

## Migration Steps

### Step 1: Generate MySQL Migrations
```bash
npx drizzle-kit generate --config=drizzle.config.mysql.ts
```

### Step 2: Run Database Migrations
```bash
npx drizzle-kit push --config=drizzle.config.mysql.ts
```

### Step 3: Migrate Your Data
```bash
npx tsx scripts/migrate-to-mysql.ts
```

### Step 4: Update Database Connection
Replace the PostgreSQL connection in `server/db.ts` with MySQL:

```typescript
// Replace existing db import with:
export { db } from './mysql-db';
```

## File Structure for MySQL

```
├── server/
│   ├── mysql-db.ts          # MySQL connection setup
│   └── db.ts               # Database exports
├── scripts/
│   └── migrate-to-mysql.ts  # Data migration script
├── drizzle.config.mysql.ts  # MySQL config
└── migrations-mysql/        # MySQL migrations
```

## Deployment Commands

### Build for Production
```bash
npm run build
```

### Start Production Server
```bash
npm start
```

## Environment Setup

### 1. Railway Deployment
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway add mysql
railway deploy
```

### 2. PlanetScale Setup
```bash
# Install PlanetScale CLI
npm install -g @planetscale/cli

# Create database
pscale database create kark-website
pscale connect kark-website main --port 3309
```

### 3. Vercel + PlanetScale
```bash
# Deploy to Vercel
npx vercel

# Set environment variables
vercel env add DATABASE_URL
```

## Database Schema

Your MySQL database will have these tables:
- `users` - User accounts and authentication
- `events` - Event management
- `media_items` - Photos and videos
- `albums` - Media organization
- `team_members` - Team profiles
- `contact_messages` - Contact form submissions
- `settings` - Site configuration
- `donation_methods` - Payment information
- `donation_campaigns` - Fundraising campaigns
- `hero_sliders` - Homepage carousel
- `archive_items` - Historical records
- `admin_logs` - Security logging
- `sessions` - User sessions

## Security Considerations

1. **SSL/TLS**: Ensure your DATABASE_URL uses SSL
2. **Environment Variables**: Never commit credentials to code
3. **Admin Access**: Verify admin permissions after migration
4. **Backup**: Set up regular database backups

## Testing Migration

1. **Local Testing**:
   ```bash
   # Set local DATABASE_URL
   export DATABASE_URL="mysql://user:pass@localhost:3306/kark"
   
   # Run migration
   npx tsx scripts/migrate-to-mysql.ts
   
   # Test the application
   npm run dev
   ```

2. **Production Testing**:
   - Verify all pages load correctly
   - Test admin login functionality
   - Check media uploads
   - Verify contact form submission

## Troubleshooting

### Common Issues:

1. **Connection Errors**: Verify DATABASE_URL format
2. **SSL Issues**: Add `?ssl={"rejectUnauthorized":false}` to DATABASE_URL
3. **Permission Errors**: Check MySQL user permissions
4. **Migration Failures**: Run migrations step by step

### Support:
- Check hosting platform documentation
- Verify MySQL version compatibility
- Test connection with MySQL client

## Next Steps

1. Choose your hosting platform
2. Set up MySQL database
3. Configure environment variables
4. Run the migration script
5. Deploy your application
6. Test all functionality

Your KARK website is ready for MySQL deployment!