import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { z } from "zod";
import { hashPassword } from "./auth";
import { userRoleEnum, adminLogs } from "@shared/schema";
import { db, pool } from "./db";
import { desc } from "drizzle-orm";
import { logAdminAction } from "./admin-logger";

const adminPermissionSchema = z.object({
  username: z.string().min(3),
  firstName: z.string().min(2),
  lastName: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8).optional(),
  role: z.enum(["admin", "major_admin"]),
  permissions: z.array(z.string())
});

// Middleware to check if user is a major admin
function requireMajorAdmin(req: Request, res: Response, next: Function) {
  const user = req.user as any;
  if (!user) {
    return res.status(401).json({ message: "Oturum açmanız gerekiyor" });
  }
  
  if (user.role !== "major_admin" && !user.permissions?.includes("manage_admins")) {
    return res.status(403).json({ message: "Bu işlem için yetkiniz bulunmuyor" });
  }
  
  next();
}

// Middleware to check if user is an admin (any admin level)
function requireAdmin(req: Request, res: Response, next: Function) {
  const user = req.user as any;
  if (!user) {
    return res.status(401).json({ message: "Oturum açmanız gerekiyor" });
  }
  
  if (!user.isAdmin && user.role !== "admin" && user.role !== "major_admin") {
    return res.status(403).json({ message: "Bu işlem için yetkiniz bulunmuyor" });
  }
  
  next();
}

export function registerAdminRoutes(app: Express) {
  // Get all users (for user management)
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Kullanıcılar getirilirken bir hata oluştu" });
    }
  });
  
  // Ban a user
  app.post("/api/admin/ban-user/:id", requireAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      
      // Log the user ban action
      await logAdminAction(
        (req.user as any).id,
        "Kullanıcı Banlama",
        `Kullanıcı banlandı: ID ${userId}`,
        "users",
        userId,
        req
      );
      
      await storage.banUser(userId);
      res.status(200).json({ message: "Kullanıcı başarıyla banlandı" });
    } catch (error) {
      console.error("Error banning user:", error);
      res.status(500).json({ 
        message: "Kullanıcı banlanırken bir hata oluştu", 
        error: (error as Error).message 
      });
    }
  });
  
  // Unban a user
  app.post("/api/admin/unban-user/:id", requireAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      
      // Log the user unban action
      await logAdminAction(
        (req.user as any).id,
        "Kullanıcı Yasağı Kaldırma",
        `Kullanıcı yasağı kaldırıldı: ID ${userId}`,
        "users",
        userId,
        req
      );
      
      await storage.unbanUser(userId);
      res.status(200).json({ message: "Kullanıcı yasağı başarıyla kaldırıldı" });
    } catch (error) {
      console.error("Error unbanning user:", error);
      res.status(500).json({ 
        message: "Kullanıcı yasağı kaldırılırken bir hata oluştu", 
        error: (error as Error).message 
      });
    }
  });
  // Get admin logs (only available to major_admin)
  app.get("/api/admin-logs", requireMajorAdmin, async (req, res) => {
    try {
      // Get query parameters for filtering
      const limit = parseInt(req.query.limit as string) || 100;
      const offset = parseInt(req.query.offset as string) || 0;
      const resourceType = req.query.resourceType as string;
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      console.log(`Fetching logs with filters - resourceType: ${resourceType}, userId: ${userId}, limit: ${limit}, offset: ${offset}`);
      
      // Read admin logs from JSON file
      const fs = await import('fs/promises');
      const path = await import('path');
      const ADMIN_LOGS_FILE = path.join(process.cwd(), 'data', 'admin_logs.json');
      
      let logs = [];
      try {
        const data = await fs.readFile(ADMIN_LOGS_FILE, 'utf-8');
        logs = JSON.parse(data) || [];
      } catch (error) {
        console.error('Error reading admin logs:', error);
        logs = [];
      }
      
      // Apply filters
      let filteredLogs = logs;
      
      if (resourceType && resourceType !== 'all') {
        filteredLogs = filteredLogs.filter(log => log.resource_type === resourceType || log.resourceType === resourceType);
      }
      
      if (userId) {
        filteredLogs = filteredLogs.filter(log => log.user_id === userId || log.userId === userId);
      }
      
      // Get total count before pagination
      const totalCount = filteredLogs.length;
      
      // Apply pagination
      const paginatedLogs = filteredLogs.slice(offset, offset + limit);
      
      // Transform logs to match expected format (handle both snake_case and camelCase)
      const transformedLogs = paginatedLogs.map(log => ({
        id: log.id,
        user_id: log.userId || log.user_id,
        action: log.action,
        details: log.details,
        ip_address: log.ipAddress || log.ip_address,
        user_agent: log.userAgent || log.user_agent,
        resource_type: log.resourceType || log.resource_type,
        resource_id: log.resourceId || log.resource_id,
        timestamp: log.timestamp
      }));
      
      res.json({
        logs: transformedLogs,
        pagination: {
          total: totalCount,
          limit,
          offset
        }
      });
    } catch (error) {
      console.error("Error fetching admin logs:", error);
      res.status(500).json({ message: "Yönetici kayıtları getirilirken bir hata oluştu" });
    }
  });
  // Get all admin users
  app.get("/api/admins", requireMajorAdmin, async (req, res) => {
    try {
      const users = await storage.getAllAdmins();
      res.json(users);
    } catch (error) {
      console.error("Error fetching admins:", error);
      res.status(500).json({ message: "Admin kullanıcıları getirirken bir hata oluştu" });
    }
  });
  
  // Create a new admin user
  app.post("/api/admins", requireMajorAdmin, async (req, res) => {
    try {
      const validatedData = adminPermissionSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Bu kullanıcı adı zaten kullanımda" });
      }
      
      if (!validatedData.password) {
        return res.status(400).json({ message: "Şifre gereklidir" });
      }
      
      // Create admin user with hashed password
      const adminUser = await storage.createUser({
        username: validatedData.username,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        email: validatedData.email,
        password: await hashPassword(validatedData.password),
        role: validatedData.role,
        permissions: validatedData.permissions
      });
      
      // Log the admin user creation
      await logAdminAction(
        (req.user as any).id,
        "Admin Kullanıcı Oluşturma",
        `Yeni admin kullanıcı oluşturuldu: ${validatedData.username} (${validatedData.role})`,
        "users",
        adminUser.id.toString(),
        req
      );
      
      res.status(201).json(adminUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Geçersiz veri", errors: error.errors });
      }
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "Admin kullanıcı oluşturulurken bir hata oluştu" });
    }
  });
  
  // Update an existing admin user
  app.put("/api/admins/:id", requireMajorAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Make sure the user exists and is an admin
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Current user cannot modify their own role/permissions unless they are the supermanager
      const currentUser = req.user as any;
      if (currentUser.id === userId && currentUser.role !== "major_admin" && 
          (req.body.role !== existingUser.role || JSON.stringify(req.body.permissions) !== JSON.stringify(existingUser.permissions))) {
        return res.status(403).json({ message: "Kendi rolünüzü veya izinlerinizi değiştiremezsiniz" });
      }
      
      const validatedData = adminPermissionSchema.omit({ password: true }).parse(req.body);
      
      // Update the admin user
      const updatedUser = await storage.updateAdmin(userId, {
        ...validatedData
      });
      
      // Log the admin user update
      await logAdminAction(
        (req.user as any).id,
        "Admin Kullanıcı Güncelleme",
        `Admin kullanıcı güncellendi: ${validatedData.username} (${validatedData.role})`,
        "users",
        userId.toString(),
        req
      );
      
      res.json(updatedUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Geçersiz veri", errors: error.errors });
      }
      console.error("Error updating admin:", error);
      res.status(500).json({ message: "Admin kullanıcı güncellenirken bir hata oluştu" });
    }
  });
  
  // Delete an admin user
  app.delete("/api/admins/:id", requireMajorAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Make sure the user exists
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Prevent deleting yourself
      const currentUser = req.user as any;
      if (currentUser.id === userId) {
        return res.status(403).json({ message: "Kendi hesabınızı silemezsiniz" });
      }
      
      // Store user details before deletion for logging
      const userBeingDeleted = existingUser.username;
      const userRole = existingUser.role;
      
      // Delete the user
      await storage.deleteUser(userId);
      
      // Log the admin user deletion
      await logAdminAction(
        (req.user as any).id,
        "Admin Kullanıcı Silme",
        `Admin kullanıcı silindi: ${userBeingDeleted} (${userRole})`,
        "users",
        userId.toString(),
        req
      );
      
      res.status(200).json({ message: "Admin kullanıcı başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting admin:", error);
      res.status(500).json({ message: "Admin kullanıcı silinirken bir hata oluştu" });
    }
  });
}