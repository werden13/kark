import { db, pool } from "./server/db";
import { users, userRoleEnum } from "./shared/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "./server/auth";

async function setupSupermanager() {
  try {
    console.log("Checking for existing supermanager account...");
    
    // First check if supermanager exists
    const existingUser = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "supermanager")
    });
    
    if (existingUser) {
      console.log("Updating existing supermanager account with full permissions...");
      
      // Update existing supermanager with all permissions
      await db.update(users)
        .set({
          role: "major_admin",
          permissions: [
            "manage_users", 
            "manage_events", 
            "manage_media", 
            "manage_team", 
            "manage_donations", 
            "manage_settings", 
            "manage_sliders", 
            "manage_admins", 
            "all"
          ],
          isAdmin: true
        })
        .where(eq(users.username, "supermanager"));
      
      console.log("Supermanager account updated with full permissions");
    } else {
      console.log("Creating new supermanager account...");
      
      // Create a new supermanager with all permissions
      const hashedPassword = await hashPassword("supermanager123");
      
      await db.insert(users).values({
        username: "supermanager",
        password: hashedPassword,
        firstName: "Super",
        lastName: "Manager",
        email: "super@example.com",
        isAdmin: true,
        role: "major_admin",
        permissions: [
          "manage_users", 
          "manage_events", 
          "manage_media", 
          "manage_team", 
          "manage_donations", 
          "manage_settings", 
          "manage_sliders", 
          "manage_admins", 
          "all"
        ]
      });
      
      console.log("Supermanager account created with full permissions");
    }
    
    console.log("Supermanager setup complete!");
    console.log("Login with username: supermanager, password: supermanager123");
    
  } catch (error) {
    console.error("Error setting up supermanager account:", error);
  } finally {
    // Close the connection pool
    process.exit(0);
  }
}

setupSupermanager();