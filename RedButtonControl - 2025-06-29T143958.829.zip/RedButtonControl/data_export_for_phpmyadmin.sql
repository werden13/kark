-- Data Export from JSON to MySQL
-- Generated on: 2025-06-27T12:39:44.085Z
-- 
-- IMPORTANT: Update the passwords after import!

SET FOREIGN_KEY_CHECKS = 0;

-- Users data
TRUNCATE TABLE `users`;
INSERT INTO users (id, username, password, first_name, last_name, email, role, permissions, created_at, updated_at) VALUES (1, 'admin', 'b34b3c21aac175c9f82dfcfec7c3e788d77edee53be2d4b2603d1a4792252be8741aa7ebf5f2e5534acfae2bae28155cb7483bd513c57d51adfe7c21024c3cb9.11b3b1488ef75e26fe719c9663454cdf', 'Admin', 'User', 'admin@example.com', 'major_admin', '["manage_users","manage_events","manage_media","manage_team","manage_donations","manage_settings","manage_sliders","manage_admins","all"]', '2025-05-16 21:40:54', NULL);
INSERT INTO users (id, username, password, first_name, last_name, email, role, permissions, created_at, updated_at) VALUES (2, 'supermanager', '23490f476ec3d0bca5fae9c2d2dba2b7b43f25599facec7f953848e6e756581b37fff09de2098be0d2ce389604367a060597362567c7515bfd48486ec3c308de.ac3f7c4fd261b94350ae88ff0f58b081', 'Super', 'Manager', 'super@example.com', 'major_admin', '["manage_users","manage_events","manage_media","manage_team","manage_donations","manage_settings","manage_sliders","manage_admins","all"]', '2025-05-18 09:53:15', NULL);

-- Settings data
TRUNCATE TABLE `settings`;
INSERT INTO settings (id, `key`, value, type, description) VALUES (1, 'general.footer_text', 'lol', 'string', NULL);

-- Hero Sliders data
TRUNCATE TABLE `hero_sliders`;
INSERT INTO hero_sliders (id, title, description, image_url, button_text, button_link, is_active, order_index) VALUES (1, 'ergrtg', 'hwggrwhrwt', 'https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080', 'Detaylar', '/', 1, 0);
INSERT INTO hero_sliders (id, title, description, image_url, button_text, button_link, is_active, order_index) VALUES (2, 'ergrtg', 'gerqgqggg', 'https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080', 'Detaylar', '/', 1, 0);

-- Admin Logs data
TRUNCATE TABLE `admin_logs`;
INSERT INTO admin_logs (id, user_id, action, details, ip_address, user_agent, resource_type, resource_id, timestamp) VALUES (2, 1, 'Yetkisiz Giriş Denemesi', 'Korumalı admin hesabına başarısız giriş denemesi: admin', '127.0.0.1', 'curl/8.11.1', 'security', 'admin-login', '2025-06-27 10:47:02');
INSERT INTO admin_logs (id, user_id, action, details, ip_address, user_agent, resource_type, resource_id, timestamp) VALUES (1, 2, 'Güvenlik Sistemi Test', 'Güvenlik kayıtları sisteminin test edilmesi', '127.0.0.1', 'Test Script', 'security', 'test-1', '2025-06-27 08:32:38');

-- Contact messages data
TRUNCATE TABLE `contact`;
INSERT INTO contact (id, name, email, subject, message, phone, is_read, admin_notes, created_at) VALUES (1, 'mghmyrmm', 'ornek@mail.com', 'cooperation', 'gelkrmgerg', NULL, 1, NULL, '2025-05-16 15:18:07');

-- Archive Items data
TRUNCATE TABLE `archive_items`;
INSERT INTO archive_items (id, title, description, content, type, date, location, participants, images, videos, documents, tags, is_featured, is_active, view_count) VALUES (1, 'egqewg', 'qwgeqrgqe', 'ggqegqegeqg', NULL, '2025-06-26T19:57:36.986Z', 'gqegqeg', '"gqegeg"', NULL, NULL, NULL, '["ergrgergr"]', 1, 1, 1);

SET FOREIGN_KEY_CHECKS = 1;

-- Export completed successfully!
-- Remember to update passwords after import for security.
