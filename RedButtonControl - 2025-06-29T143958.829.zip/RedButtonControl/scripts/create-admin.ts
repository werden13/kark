import { db } from "../server/db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "../server/auth";

async function createSuperManager() {
  try {
    // First check if supermanager already exists
    const existingUser = await db.select().from(users).where(eq(users.username, "supermanager")).execute();
    
    if (existingUser.length > 0) {
      console.log("Supermanager account already exists");
      return;
    }
    
    // Create the supermanager account
    const hashedPassword = await hashPassword("SuperManager2024!");
    
    await db.insert(users).values({
      username: "supermanager",
      password: hashedPassword,
      firstName: "Super",
      lastName: "Manager",
      email: "supermanager@example.com",
      isAdmin: true,
      role: "major_admin",
      permissions: ["all"]
    });
    
    console.log("Supermanager account created successfully");
  } catch (error) {
    console.error("Error creating supermanager account:", error);
  } finally {
    process.exit(0);
  }
}

createSuperManager();