# cPanel'de MySQL Veritabanı Oluşturma Rehberi

## Adım 1: cPanel'e Giriş Yapın
1. cPanel hesabınıza giriş yapın (genellikle `yourdomain.com/cpanel`)
2. Kullanıcı adı ve şifrenizi girin

## Adım 2: MySQL Databases Bölümüne Gidin
1. cPanel ana sayfasında **"Databases"** bölümünü bulun
2. **"MySQL Databases"** ikonuna tıklayın

## Adım 3: Yeni Veritabanı Oluşturun
1. **"Create New Database"** (Yeni Veritabanı Oluştur) bölümünü bulun
2. Veritabanı adı girin: `kark` (cPanel otomatik olarak prefix ekler)
   - Örnek: Eğer cPanel prefix'iniz `mysite_` ise, veritabanı adı `mysite_kark` olur
3. **"Create Database"** butonuna tıklayın

## Adım 4: MySQL Kullanıcısı Oluşturun
1. **"MySQL Users"** (MySQL Kullanıcıları) bölümüne gidin
2. **"Add New User"** (Yeni Kullanıcı Ekle) bölümünde:
   - Username: `karkuser` (yine prefix eklenecek)
   - Password: Güçlü bir şifre girin
   - Password Generator kullanabilirsiniz
3. **"Create User"** butonuna tıklayın
4. **ŞİFREYİ NOT EDİN!** Bunu .env dosyasında kullanacaksınız

## Adım 5: Kullanıcıyı Veritabanına Ekleyin
1. **"Add User To Database"** (Kullanıcıyı Veritabanına Ekle) bölümünü bulun
2. User: Az önce oluşturduğunuz kullanıcıyı seçin (örn: `mysite_karkuser`)
3. Database: Oluşturduğunuz veritabanını seçin (örn: `mysite_kark`)
4. **"Add"** butonuna tıklayın

## Adım 6: Tüm Yetkileri Verin (ALL PRIVILEGES)
1. Yeni bir sayfa açılacak: **"Manage User Privileges"**
2. **"ALL PRIVILEGES"** kutusunu işaretleyin (en üstte)
   - Veya tüm kutuları tek tek işaretleyin
3. **"Make Changes"** butonuna tıklayın

## Oluşturduğunuz Bilgiler:
Örnek olarak, eğer cPanel prefix'iniz `mysite_` ise:
- **Veritabanı Adı**: `mysite_kark`
- **Kullanıcı Adı**: `mysite_karkuser`
- **Şifre**: Oluşturduğunuz güçlü şifre

## .env Dosyasında Kullanım:
```env
DB_TYPE=mysql
DB_HOST=localhost
DB_USER=mysite_karkuser
DB_PASSWORD=oluşturduğunuz_şifre
DB_NAME=mysite_kark
DB_PORT=3306
```

## Önemli Notlar:
- cPanel otomatik olarak kullanıcı adı ve veritabanı adına prefix ekler
- Prefix'inizi cPanel ana sayfasının sol üst köşesinde görebilirsiniz
- Şifreyi güvenli bir yerde saklayın
- ALL PRIVILEGES vermek önemli, yoksa uygulama çalışmaz

## Sonraki Adım:
Veritabanı oluşturduktan sonra:
1. phpMyAdmin'e gidin
2. Sol taraftan veritabanınızı seçin
3. Import (İçe Aktar) sekmesine tıklayın
4. `kark_complete_database_cpanel_fixed.sql` dosyasını yükleyin