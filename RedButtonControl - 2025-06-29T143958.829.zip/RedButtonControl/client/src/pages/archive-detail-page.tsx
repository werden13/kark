import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArchiveItem } from "@shared/schema";
import { formatDate } from "@/lib/utils";
import { Loader2, ArrowLeft, Calendar, MapPin, Users, Target, Image, Video, FileText, Eye, Share2 } from "lucide-react";
import ImageWithFallback from "@/components/ImageWithFallback";

export default function ArchiveDetailPage() {
  const { id } = useParams();
  const [, setLocation] = useLocation();

  const { data: archiveItem, isLoading, error } = useQuery<ArchiveItem>({
    queryKey: [`/api/archive/${id}`],
    queryFn: async () => {
      const response = await fetch(`/api/archive/${id}`);
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("Arşiv öğesi bulunamadı");
        }
        throw new Error("Arşiv öğesi yüklenemedi");
      }
      return response.json();
    },
    enabled: !!id,
  });

  const getTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      operation: "Operasyon",
      training: "Eğitim", 
      event: "Etkinlik",
      report: "Rapor",
      news: "Haber"
    };
    return types[type] || type;
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      operation: "bg-blue-100 text-blue-800",
      training: "bg-green-100 text-green-800",
      event: "bg-purple-100 text-purple-800", 
      report: "bg-orange-100 text-orange-800",
      news: "bg-red-100 text-red-800"
    };
    return colors[type] || "bg-gray-100 text-gray-800";
  };

  if (isLoading) {
    return (
      <>
        <Navbar />
        <main className="content-container">
          <div className="container mx-auto px-4">
            <div className="flex justify-center py-20">
              <Loader2 className="h-12 w-12 animate-spin text-secondary" />
            </div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  if (error || !archiveItem) {
    return (
      <>
        <Navbar />
        <main className="content-container">
          <div className="container mx-auto px-4">
            <div className="text-center py-20">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Arşiv Öğesi Bulunamadı</h1>
              <p className="text-gray-600 mb-8">Aradığınız arşiv öğesi mevcut değil veya kaldırılmış olabilir.</p>
              <Button onClick={() => setLocation("/archive")}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Arşive Dön
              </Button>
            </div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{archiveItem.title} | KARK Arama Kurtarma</title>
        <meta name="description" content={archiveItem.description} />
        <meta name="keywords" content={`KARK, arama kurtarma, ${getTypeLabel(archiveItem.itemType).toLowerCase()}, ${archiveItem.tags?.join(', ')}`} />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          {/* Back Button */}
          <div className="mb-6">
            <Button variant="ghost" onClick={() => setLocation("/archive")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Arşive Dön
            </Button>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Article Content */}
            <div className="lg:col-span-2">
              <Card className="mb-6">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-4">
                    <Badge className={getTypeColor(archiveItem.itemType)}>
                      {getTypeLabel(archiveItem.itemType)}
                    </Badge>
                    <span className="text-sm text-gray-500">{formatDate(archiveItem.date)}</span>
                  </div>
                  <CardTitle className="text-3xl font-bold mb-4">{archiveItem.title}</CardTitle>
                  <CardDescription className="text-lg">{archiveItem.description}</CardDescription>
                </CardHeader>
                
                {archiveItem.imageUrl && (
                  <div className="px-6 mb-6">
                    <ImageWithFallback 
                      src={archiveItem.imageUrl} 
                      alt={archiveItem.title}
                      className="w-full h-64 object-cover rounded-lg"
                      fallbackClassName="w-full h-64 rounded-lg"
                    />
                  </div>
                )}

                <CardContent>
                  {archiveItem.content && (
                    <div className="prose max-w-none mb-6">
                      <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
                        {archiveItem.content}
                      </div>
                    </div>
                  )}

                  <Separator className="my-6" />

                  {/* Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {archiveItem.location && (
                      <div className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <div className="font-semibold text-gray-900">Konum</div>
                          <div className="text-gray-600">{archiveItem.location}</div>
                        </div>
                      </div>
                    )}

                    {archiveItem.participants && (
                      <div className="flex items-start gap-3">
                        <Users className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <div className="font-semibold text-gray-900">Katılımcılar</div>
                          <div className="text-gray-600">{archiveItem.participants}</div>
                        </div>
                      </div>
                    )}

                    {archiveItem.outcome && (
                      <div className="flex items-start gap-3 md:col-span-2">
                        <Target className="w-5 h-5 text-purple-600 mt-0.5" />
                        <div>
                          <div className="font-semibold text-gray-900">Sonuç</div>
                          <div className="text-gray-600">{archiveItem.outcome}</div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Media Links */}
                  {(archiveItem.videoUrl || archiveItem.documentUrl) && (
                    <>
                      <Separator className="my-6" />
                      <div className="space-y-3">
                        <h3 className="font-semibold text-gray-900">Ek Dosyalar</h3>
                        <div className="flex flex-wrap gap-3">
                          {archiveItem.videoUrl && (
                            <a
                              href={archiveItem.videoUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors"
                            >
                              <Video className="w-4 h-4" />
                              Video İzle
                            </a>
                          )}
                          {archiveItem.documentUrl && (
                            <a
                              href={archiveItem.documentUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors"
                            >
                              <FileText className="w-4 h-4" />
                              Belgeyi Görüntüle
                            </a>
                          )}
                        </div>
                      </div>
                    </>
                  )}

                  {/* Tags */}
                  {archiveItem.tags && archiveItem.tags.length > 0 && (
                    <>
                      <Separator className="my-6" />
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-3">Etiketler</h3>
                        <div className="flex flex-wrap gap-2">
                          {archiveItem.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    İstatistikler
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Görüntülenme</span>
                      <span className="font-semibold">{archiveItem.viewCount || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Yayın Tarihi</span>
                      <span className="font-semibold">{formatDate(archiveItem.createdAt)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Son Güncelleme</span>
                      <span className="font-semibold">{formatDate(archiveItem.updatedAt)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Share2 className="w-5 h-5" />
                    Paylaş
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => {
                        navigator.clipboard.writeText(window.location.href);
                        // Show toast notification would be nice here
                      }}
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      Linki Kopyala
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => {
                        const text = `${archiveItem.title} - KARK Arama Kurtarma ${window.location.href}`;
                        if (navigator.share) {
                          navigator.share({ title: archiveItem.title, text, url: window.location.href });
                        } else {
                          navigator.clipboard.writeText(text);
                        }
                      }}
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Paylaş
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}