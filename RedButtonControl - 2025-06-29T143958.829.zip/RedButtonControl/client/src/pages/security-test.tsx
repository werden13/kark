import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Helmet } from "react-helmet-async";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export default function SecurityTestPage() {
  const [username, setUsername] = useState("supermanager");
  const [password, setPassword] = useState("wrongpassword");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  
  const testLogin = async () => {
    setLoading(true);
    
    try {
      // Store username in sessionStorage for jumpscare page
      sessionStorage.setItem('attempted_username', username);
      
      // Attempt login 
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password }),
      });
      
      // Check for security alert
      if (response.status === 403) {
        const data = await response.json();
        if (data.securityAlert) {
          toast({
            title: "Security Alert Triggered",
            description: "Redirecting to security alert page...",
            variant: "destructive"
          });
          
          setTimeout(() => {
            window.location.href = '/security/alert';
          }, 1000);
          return;
        }
      }
      
      // Regular response handling
      const data = await response.json();
      toast({
        title: "Login Result",
        description: `Response: ${JSON.stringify(data)}`,
      });
      
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "An error occurred",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <>
      <Helmet>
        <title>Security Test | Admin Security</title>
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle>Security System Test</CardTitle>
              <CardDescription>
                Test the jumpscare redirect system by attempting to login with admin credentials
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input 
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter admin username"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Password (intentionally wrong)</Label>
                <Input 
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter wrong password"
                />
              </div>
            </CardContent>
            
            <CardFooter>
              <Button 
                onClick={testLogin}
                disabled={loading}
                className="w-full"
              >
                {loading ? "Testing..." : "Test Security System"}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </main>
      
      <Footer />
    </>
  );
}