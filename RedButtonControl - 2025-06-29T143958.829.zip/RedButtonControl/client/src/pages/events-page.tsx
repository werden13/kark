import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import EventCard from "@/components/home/EventCard";
import { Button } from "@/components/ui/button";
import { Event } from "@shared/schema";
import { Loader2 } from "lucide-react";

export default function EventsPage() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const initialCategory = searchParams.get("category") || "all";
  
  const [activeCategory, setActiveCategory] = useState(initialCategory);

  const { data: events, isLoading } = useQuery<Event[]>({
    queryKey: [
      activeCategory === "all" 
        ? "/api/events" 
        : `/api/events?category=${activeCategory}`
    ],
  });

  const handleCategoryChange = (category: string) => {
    setActiveCategory(category);
  };

  return (
    <>
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">Etkinlikler ve Faaliyetler</h1>
            </div>
            <p className="section-description">
              Tüm etkinliklerimiz ve faaliyetlerimizi keşfedin
            </p>
          </div>
          
          {/* Event Filters */}
          <div className="mb-8 flex flex-wrap justify-center gap-4">
            <Button 
              variant={activeCategory === "all" ? "default" : "outline"} 
              className={activeCategory === "all" ? "bg-dark text-white" : ""} 
              onClick={() => handleCategoryChange("all")}
            >
              Tüm Etkinlikler
            </Button>
            <Button 
              variant={activeCategory === "rescue" ? "default" : "outline"} 
              className={activeCategory === "rescue" ? "bg-dark text-white" : ""} 
              onClick={() => handleCategoryChange("rescue")}
            >
              Arama Kurtarma
            </Button>
            <Button 
              variant={activeCategory === "training" ? "default" : "outline"} 
              className={activeCategory === "training" ? "bg-dark text-white" : ""} 
              onClick={() => handleCategoryChange("training")}
            >
              Eğitim
            </Button>
            <Button 
              variant={activeCategory === "donation" ? "default" : "outline"} 
              className={activeCategory === "donation" ? "bg-dark text-white" : ""} 
              onClick={() => handleCategoryChange("donation")}
            >
              Bağış
            </Button>
            <Button 
              variant={activeCategory === "awareness" ? "default" : "outline"} 
              className={activeCategory === "awareness" ? "bg-dark text-white" : ""} 
              onClick={() => handleCategoryChange("awareness")}
            >
              Farkındalık
            </Button>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-secondary" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {events && events.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
              
              {(!events || events.length === 0) && (
                <div className="col-span-1 md:col-span-2 lg:col-span-3 text-center py-8">
                  <p className="text-gray-500">
                    Bu kategoride etkinlik bulunamadı
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </>
  );
}
