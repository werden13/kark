import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Helmet } from "react-helmet-async";
import { Loader2 } from "lucide-react";
import { LoadingSpinner, ContentLoader } from "@/components/ui/loading-spinner";

import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

// Login form schema
const loginSchema = z.object({
  username: z.string().min(3, "Kullanıcı adı en az 3 karakter olmalıdır"),
  password: z.string().min(8, "Şifre en az 8 karakter olmalıdır"),
  rememberMe: z.boolean().optional(),
});

// Registration form schema with password confirmation
const registerSchema = z.object({
  firstName: z.string().min(2, "Ad en az 2 karakter olmalıdır"),
  lastName: z.string().min(2, "Soyad en az 2 karakter olmalıdır"),
  username: z.string().min(3, "Kullanıcı adı en az 3 karakter olmalıdır"),
  email: z.string().email("Geçerli bir e-posta adresi giriniz"),
  password: z.string()
    .min(8, "Şifre en az 8 karakter olmalıdır")
    .regex(/[A-Z]/, "Şifre en az bir büyük harf içermelidir")
    .regex(/[0-9]/, "Şifre en az bir rakam içermelidir")
    .regex(/[^a-zA-Z0-9]/, "Şifre en az bir özel karakter içermelidir"),
  confirmPassword: z.string(),
  acceptTerms: z.boolean().refine(val => val === true, {
    message: "Kullanım koşullarını kabul etmelisiniz",
  })
}).refine((data) => data.password === data.confirmPassword, {
  message: "Şifreler eşleşmiyor",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [location, navigate] = useLocation();
  const [pageLoading, setPageLoading] = useState(true);
  
  // Determine which form to show based on URL parameter
  const urlParams = new URLSearchParams(window.location.search);
  const showRegisterForm = urlParams.get("action") === "register";
  
  // Show initial loading animation
  useEffect(() => {
    const timer = setTimeout(() => {
      setPageLoading(false);
    }, 600);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      // If user is admin, redirect to admin dashboard, otherwise to home
      if (user.isAdmin || user.role === 'major_admin' || user.role === 'admin') {
        navigate("/admin");
      } else {
        navigate("/");
      }
    }
  }, [user, navigate]);

  // Login form setup
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  // Register form setup
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      acceptTerms: false,
    },
  });

  // Form submission handlers
  function onLoginSubmit(values: LoginFormValues) {
    loginMutation.mutate({
      username: values.username,
      password: values.password,
    });
  }

  function onRegisterSubmit(values: RegisterFormValues) {
    // Log the form values for debugging
    console.log('Registration values:', values);
    
    try {
      // Send the required fields to the API
      // We're casting to any to bypass TypeScript's strict type checking
      // This is necessary because our server handles the confirmPassword field
      registerMutation.mutate({
        username: values.username,
        firstName: values.firstName,
        lastName: values.lastName,
        email: values.email,
        password: values.password,
        confirmPassword: values.confirmPassword, // Server will validate this
        role: "user", 
        permissions: null
      } as any);
    } catch (error) {
      console.error('Error preparing registration data:', error);
    }
  }

  // If user is logged in or page is loading, show loading spinner
  if (user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-secondary" />
      </div>
    );
  }
  
  if (pageLoading) {
    return (
      <>
        <Navbar />
        <main className="content-container">
          <div className="container mx-auto px-4 py-8">
            <ContentLoader />
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{showRegisterForm ? "Kayıt Ol" : "Giriş Yap"} | KARK</title>
        <meta name="description" content="KARK'a giriş yapın veya yeni bir hesap oluşturun. Etkinliklerimize kayıt olun ve topluluğumuza katılın." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4 py-8 animate-fadeIn">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              {/* Logo and Custom Tab Navigation */}
              <div className="mb-8">
                {/* Logo */}
                <div className="flex justify-center mb-6">
                  <img 
                    src="/kark-logo.png" 
                    alt="KARK Logo" 
                    className="h-24 w-auto"
                  />
                </div>
                
                <div className="grid w-full grid-cols-2 rounded-lg overflow-hidden">
                  <a 
                    href="/auth" 
                    className={`py-3 px-5 text-center font-medium ${!showRegisterForm ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700'}`}
                  >
                    Giriş Yap
                  </a>
                  <a 
                    href="/auth?action=register" 
                    className={`py-3 px-5 text-center font-medium ${showRegisterForm ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700'}`}
                  >
                    Kayıt Ol
                  </a>
                </div>
              </div>
              
              {/* Login Form */}
              {!showRegisterForm && (
                <Card className="auth-form-animation">
                  <CardHeader>
                    <CardTitle>Giriş Yap</CardTitle>
                    <CardDescription>
                      Hesabınıza giriş yaparak etkinliklere katılabilir ve içeriklere erişebilirsiniz.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...loginForm}>
                      <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                        <FormField
                          control={loginForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Kullanıcı Adı</FormLabel>
                              <FormControl>
                                <Input placeholder="kullanici_adi" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Şifre</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={loginForm.control}
                          name="rememberMe"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Beni hatırla</FormLabel>
                              </div>
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={loginMutation.isPending}
                        >
                          {loginMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Giriş yapılıyor...
                            </>
                          ) : (
                            "Giriş Yap"
                          )}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                  <CardFooter className="flex justify-center">
                    <a href="/auth?action=register" className="text-primary hover:underline">
                      Hesabınız yok mu? <span className="font-semibold">Kaydolun</span>
                    </a>
                  </CardFooter>
                </Card>
              )}
              
              {/* Registration Form */}
              {showRegisterForm && (
                <Card className="auth-form-animation">
                  <CardHeader>
                    <CardTitle>Kayıt Ol</CardTitle>
                    <CardDescription>
                      Yeni bir hesap oluşturarak etkinliklerimize katılabilir ve özel içeriklere erişebilirsiniz.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...registerForm}>
                      <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={registerForm.control}
                            name="firstName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Ad</FormLabel>
                                <FormControl>
                                  <Input placeholder="Adınız" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={registerForm.control}
                            name="lastName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Soyad</FormLabel>
                                <FormControl>
                                  <Input placeholder="Soyadınız" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={registerForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Kullanıcı Adı</FormLabel>
                              <FormControl>
                                <Input placeholder="kullanici_adi" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>E-posta</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="ornek@mail.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Şifre</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <p className="text-xs text-gray-500 mt-1">
                                En az 8 karakter, bir büyük harf, bir rakam ve bir özel karakter içermelidir.
                              </p>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Şifre Tekrar</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="acceptTerms"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  Kullanım koşullarını ve gizlilik politikasını kabul ediyorum
                                </FormLabel>
                                <FormMessage />
                              </div>
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={registerMutation.isPending}
                        >
                          {registerMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Kayıt işlemi yapılıyor...
                            </>
                          ) : (
                            "Kayıt Ol"
                          )}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                  <CardFooter className="flex justify-center">
                    <a href="/auth" className="text-secondary hover:underline">
                      Zaten hesabınız var mı? <span className="font-semibold">Giriş yapın</span>
                    </a>
                  </CardFooter>
                </Card>
              )}
            </div>
            
            {/* Hero Section */}
            <div className="bg-gray-900 rounded-lg p-10 text-white hidden lg:block animate-slideIn">
              <h2 className="text-3xl font-bold mb-6">
                <span style={{ 
                  color: '#FF0000', 
                  textShadow: '2px 2px 0 #000', 
                  WebkitTextStroke: '1px #000'
                }}>K</span>
                <span style={{ 
                  color: '#FFFFFF', 
                  textShadow: '2px 2px 0 #000', 
                  WebkitTextStroke: '1px #000'
                }}>A</span>
                <span style={{ 
                  color: '#FF0000', 
                  textShadow: '2px 2px 0 #000', 
                  WebkitTextStroke: '1px #000'
                }}>RK</span>
                <span className="ml-2 text-white">'a Hoş Geldiniz</span>
              </h2>
              <p className="mb-6">
                Arama kurtarma, afet yönetimi ve acil durum eğitimleriyle toplumsal hazırlık seviyesini yükseltiyoruz.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-secondary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span>Arama kurtarma eğitimlerine katılın</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-secondary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span>Afet hazırlık bilgilerine erişin</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-secondary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span>Acil durum ekiplerine dahil olun</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-secondary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span>Doğal afet simülasyonlarına katılın</span>
                </li>
              </ul>
              <div className="mt-8">
                <img 
                  src="https://images.unsplash.com/photo-1615461066229-0456f26974ca?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80" 
                  alt="Arama Kurtarma" 
                  className="rounded-lg opacity-80" 
                />
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}