import { Helmet } from "react-helmet-async";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export default function AboutPage() {
  return (
    <>
      <Helmet>
        <title>Hakkımızda | KARK Arama Kurtarma</title>
        <meta name="description" content="KARK Arama Kurtarma Derneği hakkında bilgi edinin. Misyonumuz, vizyonumuz ve değerlerimizi öğrenin." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">Hakkımızda</h1>
            </div>
            <p className="section-description">KARK Arama Kurtarma Derneği'nin hikayesi ve misyonu</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <div className="aspect-w-16 aspect-h-9 mb-8 overflow-hidden rounded-lg shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1624894510591-41806b95a599?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                  alt="KARK Arama Kurtarma Ekibi" 
                  className="object-cover w-full h-full"
                />
              </div>
              
              <div className="aspect-w-16 aspect-h-9 overflow-hidden rounded-lg shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1610498605110-8320436cbf6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                  alt="Arama Kurtarma Operasyonu" 
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
            
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold mb-4 dark:text-white">Biz Kimiz?</h2>
                <p className="text-primary dark:text-gray-300 mb-4">
                  KARK (Kuzey Kıbrıs Arama Kurtarma), 2015 yılında Kuzey Kıbrıs Türk Cumhuriyeti'nde kurulmuş, kar amacı gütmeyen bir sivil toplum kuruluşudur. 
                  Derneğimiz, doğal afetler, acil durumlar ve kriz anlarında profesyonel arama kurtarma hizmetleri sunmak amacıyla kurulmuştur.
                </p>
                <p className="text-primary dark:text-gray-300">
                  Eğitimli gönüllülerden oluşan ekibimiz, modern ekipmanlar ve uluslararası standartlarda eğitimler ile toplumun her kesiminin güvenliği için 
                  24 saat hazır bulunmaktadır. KARK, ulusal ve uluslararası kuruluşlarla işbirliği içinde çalışarak, afet yönetimi ve arama kurtarma 
                  faaliyetlerinde etkin rol almaktadır.
                </p>
              </div>
              
              <div>
                <h2 className="text-2xl font-bold mb-4 dark:text-white">Misyonumuz</h2>
                <p className="text-primary dark:text-gray-300">
                  Kuzey Kıbrıs Türk Cumhuriyeti'nde ve ihtiyaç duyulan her yerde, afet ve acil durumlarda hayat kurtarmak, 
                  toplumun afet bilincini artırmak ve uluslararası standartlarda arama kurtarma hizmetleri sunmak için var gücümüzle çalışmak.
                </p>
              </div>
              
              <div>
                <h2 className="text-2xl font-bold mb-4 dark:text-white">Vizyonumuz</h2>
                <p className="text-primary dark:text-gray-300">
                  KKTC'de afet ve acil durum yönetiminde öncü, uluslararası alanda tanınan ve güvenilen, sürekli gelişen ve 
                  eğitim odaklı bir arama kurtarma organizasyonu olmak.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-6 text-center dark:text-white">Değerlerimiz</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow dark:shadow-blue-900/20">
                <div className="text-secondary text-3xl mb-4 flex justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center dark:text-white">İnsan Odaklılık</h3>
                <p className="text-primary dark:text-gray-300 text-center">
                  Her faaliyetimizin merkezinde insan hayatını ve onurunu korumak yer alır. 
                  Hizmetlerimizi din, dil, ırk ve cinsiyet ayrımı gözetmeksizin tüm ihtiyaç sahiplerine sunarız.
                </p>
              </div>
              
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow dark:shadow-blue-900/20">
                <div className="text-secondary text-3xl mb-4 flex justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="7" width="20" height="15" rx="2" ry="2"></rect>
                    <polyline points="17 2 12 7 7 2"></polyline>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center dark:text-white">Profesyonellik</h3>
                <p className="text-primary dark:text-gray-300 text-center">
                  Sürekli eğitim ve gelişim ile en yüksek standartları korumaya çalışırız. 
                  Her operasyonda özen, dikkat ve titizlikle hareket ederiz.
                </p>
              </div>
              
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow dark:shadow-blue-900/20">
                <div className="text-secondary text-3xl mb-4 flex justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="16"></line>
                    <line x1="8" y1="12" x2="16" y2="12"></line>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center dark:text-white">Dayanışma</h3>
                <p className="text-primary dark:text-gray-300 text-center">
                  Takım çalışması ve işbirliği tüm faaliyetlerimizin temelidir. 
                  Sivil toplum, kamu kurumları ve uluslararası organizasyonlarla güçlü işbirlikleri geliştiririz.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-8 text-center dark:text-white">Tarihçemiz</h2>
            <div className="relative border-l-4 border-secondary pl-8 ml-4 pb-8">
              <div className="mb-10 relative">
                <div className="absolute -left-[41px] top-0 bg-secondary rounded-full w-6 h-6 border-4 border-white dark:border-gray-900"></div>
                <h3 className="text-xl font-bold mb-2 dark:text-white">2015 - Kuruluş</h3>
                <p className="text-primary dark:text-gray-300">
                  KARK, bir grup gönüllü tarafından Kuzey Kıbrıs Türk Cumhuriyeti'nde afet yönetimi ve arama kurtarma alanındaki eksikliği 
                  gidermek amacıyla resmen kuruldu.
                </p>
              </div>
              
              <div className="mb-10 relative">
                <div className="absolute -left-[41px] top-0 bg-secondary rounded-full w-6 h-6 border-4 border-white dark:border-gray-900"></div>
                <h3 className="text-xl font-bold mb-2 dark:text-white">2017 - İlk Önemli Operasyon</h3>
                <p className="text-primary dark:text-gray-300">
                  Girne Dağları'nda kaybolan üç dağcının başarılı arama ve kurtarma operasyonu ile KARK, halk tarafından tanınmaya başladı.
                </p>
              </div>
              
              <div className="mb-10 relative">
                <div className="absolute -left-[41px] top-0 bg-secondary rounded-full w-6 h-6 border-4 border-white dark:border-gray-900"></div>
                <h3 className="text-xl font-bold mb-2 dark:text-white">2019 - Uluslararası İşbirliği</h3>
                <p className="text-primary dark:text-gray-300">
                  Türkiye Afet ve Acil Durum Yönetimi Başkanlığı (AFAD) ile işbirliği anlaşması imzalandı.
                </p>
              </div>
              
              <div className="relative">
                <div className="absolute -left-[41px] top-0 bg-secondary rounded-full w-6 h-6 border-4 border-white dark:border-gray-900"></div>
                <h3 className="text-xl font-bold mb-2 dark:text-white">2023 - Bugün</h3>
                <p className="text-primary dark:text-gray-300">
                  KARK, 50'den fazla aktif gönüllü üyesi, modern ekipmanları ve düzenli eğitim programları ile 
                  KKTC'nin en güvenilir arama kurtarma organizasyonlarından biri olarak hizmet vermektedir.
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-lg shadow-md mb-16 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 text-center dark:text-white">Bize Katılın</h2>
            <p className="text-primary dark:text-gray-300 text-center mb-8">
              KARK, toplumun her kesiminden gönüllülere açıktır. Arama kurtarma operasyonlarında görev almak, 
              eğitim vermek veya idari görevlerde yer almak için başvurabilirsiniz.
            </p>
            <div className="flex justify-center">
              <a href="/contact" className="bg-secondary hover:bg-blue-700 text-white font-bold py-3 px-8 rounded transition-colors duration-300">
                Gönüllü Olmak İçin Başvurun
              </a>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}