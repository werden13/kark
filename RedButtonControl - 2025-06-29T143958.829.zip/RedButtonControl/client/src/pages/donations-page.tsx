import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Copy, ExternalLink, Copy as CopyIcon } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

interface DonationMethod {
  id: number;
  bankName: string;
  accountName: string;
  iban: string;
  branchCode?: string;
  accountNumber?: string;
  currency?: string;
  description?: string;
  logoUrl?: string;
}

interface DonationCampaign {
  id: number;
  title: string;
  description: string;
  targetAmount?: number;
  currentAmount?: number;
  endDate?: string;
  imageUrl?: string;
  isActive?: boolean;
}

export default function DonationsPage() {
  const [activeTab, setActiveTab] = useState("general");
  
  // In a real app, these would come from an API
  const { data: donationMethods = [] } = useQuery<DonationMethod[]>({
    queryKey: ["/api/donation/methods"],
  });

  const { data: campaigns = [] } = useQuery<DonationCampaign[]>({
    queryKey: ["/api/donation/campaigns"],
  });

  function copyToClipboard(text: string, label: string = "Bilgi") {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Kopyalandı!",
        description: `${label} panoya kopyalandı.`,
      });
    });
  }

  const formatCurrency = (value?: number) => {
    if (!value) return "0 TL";
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(value);
  };

  const calculateProgress = (current?: number, target?: number) => {
    if (!current || !target) return 0;
    const percentage = (current / target) * 100;
    return Math.min(percentage, 100);
  };

  return (
    <>
      <Helmet>
        <title>Bağış Kampanyaları - KARK Arama Kurtarma</title>
        <meta name="description" content="KARK Arama Kurtarma Derneği'ne bağış yaparak arama kurtarma operasyonlarına destek olabilirsiniz." />
      </Helmet>
      
      <Navbar />
      
      <main className="container mx-auto px-4 py-8 mt-20 md:mt-24">
        <div className="mb-12 text-center">
          <div className="flex justify-center">
            <h1 className="section-title">Bağış Kampanyaları</h1>
          </div>
          <p className="section-description">
            Bağışlarınız sayesinde daha fazla hayat kurtarıyor, doğal afetlerde ve acil durumlarda daha etkili müdahale edebiliyoruz.
          </p>
        </div>

        <Tabs defaultValue="general" className="w-full mb-12" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 md:w-[400px] mx-auto">
            <TabsTrigger value="general">Genel Bağış</TabsTrigger>
            <TabsTrigger value="campaigns">Aktif Kampanyalar</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="mt-8">
            <div className="max-w-3xl mx-auto">
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Genel Bağış Bilgileri</CardTitle>
                  <CardDescription>
                    Genel bağışlarınız ekipman alımı, eğitim, operasyon giderleri ve diğer ihtiyaçlar için kullanılacaktır.
                  </CardDescription>
                </CardHeader>
              </Card>

              <div className="grid gap-6 md:grid-cols-1">
                {donationMethods.map((method) => (
                  <Card key={method.id} className="overflow-hidden transition-all hover:shadow-md">
                    <CardHeader className="bg-secondary/10">
                      <div className="flex items-center gap-3">
                        {method.logoUrl && (
                          <div className="h-16 w-28 rounded overflow-hidden flex-shrink-0 bg-white p-1">
                            <img 
                              src={method.logoUrl} 
                              alt={`${method.bankName} logo`} 
                              className="h-full w-full object-contain"
                              onError={(e) => {
                                // Hide broken images
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                          </div>
                        )}
                        <div>
                          <CardTitle>{method.bankName}</CardTitle>
                          <CardDescription>{method.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4 pt-6">
                      <div>
                        <div className="text-sm font-medium mb-1">Hesap Sahibi</div>
                        <div className="flex items-center justify-between">
                          <span className="text-lg font-semibold">{method.accountName}</span>
                          <Button variant="ghost" size="sm" onClick={() => copyToClipboard(method.accountName, "Hesap sahibi")} className="h-8">
                            <CopyIcon className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                    <div>
                      <div className="text-sm font-medium mb-1">IBAN</div>
                      <div className="flex items-center justify-between">
                        <code className="bg-secondary/20 p-2 rounded text-base font-mono">{method.iban}</code>
                        <Button variant="ghost" size="sm" onClick={() => copyToClipboard(method.iban, "IBAN")} className="h-8">
                          <CopyIcon className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    {(method.branchCode || method.accountNumber) && (
                      <div className="grid grid-cols-2 gap-4">
                        {method.branchCode && (
                          <div>
                            <div className="text-sm font-medium mb-1">Şube Kodu</div>
                            <div className="flex items-center justify-between">
                              <span>{method.branchCode}</span>
                              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(method.branchCode!, "Şube kodu")} className="h-8">
                                <CopyIcon className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                        {method.accountNumber && (
                          <div>
                            <div className="text-sm font-medium mb-1">Hesap No</div>
                            <div className="flex items-center justify-between">
                              <span>{method.accountNumber}</span>
                              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(method.accountNumber!, "Hesap no")} className="h-8">
                                <CopyIcon className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="bg-secondary/5 flex justify-between">
                    <span className="text-sm text-gray-500">Para Birimi: {method.currency || "TRY"}</span>
                    <Button variant="outline" size="sm" onClick={() => copyToClipboard(
                      `Banka: ${method.bankName}\nHesap Sahibi: ${method.accountName}\nIBAN: ${method.iban}${method.branchCode ? '\nŞube Kodu: ' + method.branchCode : ''}${method.accountNumber ? '\nHesap No: ' + method.accountNumber : ''}`,
                      "Tüm bilgiler"
                    )}>
                      <Copy className="h-4 w-4 mr-2" /> Tümünü Kopyala
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>

            <div className="mt-8 p-6 bg-secondary/10 rounded-lg text-center">
              <h3 className="text-lg font-semibold mb-2">Bağış Makbuzu</h3>
              <p className="mb-4">Bağışınıza ait makbuz için lütfen iletişime geçin.</p>
              <Button variant="default" className="w-full sm:w-auto">
                <ExternalLink className="h-4 w-4 mr-2" /> İletişime Geç
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="campaigns" className="mt-8">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {campaigns.map((campaign) => (
              <Card key={campaign.id} className="overflow-hidden transition-all hover:shadow-md">
                {campaign.imageUrl && (
                  <div className="aspect-video w-full overflow-hidden">
                    <img 
                      src={campaign.imageUrl} 
                      alt={campaign.title} 
                      className="h-full w-full object-cover transition-transform hover:scale-105"
                    />
                  </div>
                )}
                <CardHeader>
                  <CardTitle>{campaign.title}</CardTitle>
                  <CardDescription>{campaign.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(campaign.currentAmount !== undefined && campaign.targetAmount !== undefined) && (
                    <>
                      <div className="flex justify-between text-sm">
                        <span>Toplanan: {formatCurrency(campaign.currentAmount)}</span>
                        <span>Hedef: {formatCurrency(campaign.targetAmount)}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-secondary h-2.5 rounded-full transition-all duration-1000" 
                          style={{ width: `${calculateProgress(campaign.currentAmount, campaign.targetAmount)}%` }}
                        ></div>
                      </div>
                      <div className="text-right text-sm text-gray-500">
                        %{Math.round(calculateProgress(campaign.currentAmount, campaign.targetAmount))} tamamlandı
                      </div>
                    </>
                  )}
                  {campaign.endDate && (
                    <div className="text-sm text-gray-500">
                      Son tarih: {new Date(campaign.endDate).toLocaleDateString('tr-TR')}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Bağış Yap</Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="mt-12 p-6 bg-secondary/10 rounded-lg text-center max-w-3xl mx-auto">
            <h3 className="text-lg font-semibold mb-2">Kurumsal Bağışlar İçin</h3>
            <p className="mb-4">Kurumsal bağış yapmak için bizimle iletişime geçebilirsiniz. Size özel bağış planları oluşturabiliriz.</p>
            <Button variant="outline" className="w-full sm:w-auto">
              <ExternalLink className="h-4 w-4 mr-2" /> Kurumsal İletişim
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      <Separator className="my-12" />

      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-2xl font-bold mb-4">Bağış Hakkında Sık Sorulan Sorular</h2>
        <div className="space-y-6 text-left mt-8">
          <div>
            <h3 className="text-lg font-semibold mb-2">Bağışlarım nerede kullanılıyor?</h3>
            <p className="text-gray-600">
              Bağışlarınız arama kurtarma ekipmanları, eğitim programları, operasyon giderleri ve afet bölgelerindeki yardım çalışmaları için kullanılmaktadır.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Bağış makbuzu alabilir miyim?</h3>
            <p className="text-gray-600">
              Evet, tüm bağışlar için resmi makbuz düzenlenmektedir. Bağış sonrası bizimle iletişime geçerek makbuzunuzu talep edebilirsiniz.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Ayni bağış yapabilir miyim?</h3>
            <p className="text-gray-600">
              Evet, ekipman, malzeme ve diğer ihtiyaçlar için ayni bağış kabul ediyoruz. Güncel ihtiyaç listemiz için lütfen iletişime geçin.
            </p>
          </div>
        </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}