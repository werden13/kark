import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "../../hooks/use-toast";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Label } from "../../components/ui/label";
import { Switch } from "../../components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui/table";
import AdminLayout from "../../components/admin/AdminLayout";
import { 
  Loader2, 
  Activity, 
  Image, 
  Calendar, 
  Link2, 
  Tag, 
  Plus,
  Edit,
  Trash2,
  ArrowUp,
  ArrowDown
} from "lucide-react";
import { apiRequest } from "../../lib/queryClient";

interface ActivityData {
  id: number;
  title: string;
  description: string;
  category: string;
  imageUrl: string | null;
  date: string | null;
  link: string | null;
  displayOrder: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function ActivitiesPage() {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<ActivityData | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    imageUrl: "",
    date: "",
    link: "",
    displayOrder: 0,
    isActive: true,
  });

  // Fetch all activities
  const { data: activities, isLoading } = useQuery<ActivityData[]>({
    queryKey: ["/api/activities/all"],
  });

  // Create activity mutation
  const createMutation = useMutation({
    mutationFn: async (data: {
      title: string;
      description: string;
      category: string;
      imageUrl: string | null;
      date: string | null;
      link: string | null;
      displayOrder: number;
      isActive: boolean;
    }) => {
      const res = await apiRequest("POST", "/api/activities", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Başarılı",
        description: "Faaliyet başarıyla oluşturuldu.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activities/all"] });
      handleCloseDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Faaliyet oluşturulurken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  // Update activity mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: {
      title: string;
      description: string;
      category: string;
      imageUrl: string | null;
      date: string | null;
      link: string | null;
      displayOrder: number;
      isActive: boolean;
    } }) => {
      const res = await apiRequest("PUT", `/api/activities/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Başarılı",
        description: "Faaliyet başarıyla güncellendi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activities/all"] });
      handleCloseDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Faaliyet güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  // Delete activity mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/activities/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Başarılı",
        description: "Faaliyet başarıyla silindi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/activities/all"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Faaliyet silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  const handleOpenDialog = (activity?: ActivityData) => {
    if (activity) {
      setEditingActivity(activity);
      setFormData({
        title: activity.title,
        description: activity.description,
        category: activity.category,
        imageUrl: activity.imageUrl || "",
        date: activity.date || "",
        link: activity.link || "",
        displayOrder: activity.displayOrder,
        isActive: activity.isActive,
      });
    } else {
      setEditingActivity(null);
      setFormData({
        title: "",
        description: "",
        category: "",
        imageUrl: "",
        date: "",
        link: "",
        displayOrder: activities?.length || 0,
        isActive: true,
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingActivity(null);
    setFormData({
      title: "",
      description: "",
      category: "",
      imageUrl: "",
      date: "",
      link: "",
      displayOrder: 0,
      isActive: true,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.description || !formData.category) {
      toast({
        title: "Hata",
        description: "Lütfen zorunlu alanları doldurun.",
        variant: "destructive",
      });
      return;
    }

    const submitData = {
      ...formData,
      displayOrder: Number(formData.displayOrder),
      imageUrl: formData.imageUrl || null,
      date: formData.date || null,
      link: formData.link || null,
    };

    if (editingActivity) {
      updateMutation.mutate({ id: editingActivity.id, data: submitData });
    } else {
      createMutation.mutate(submitData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Bu faaliyeti silmek istediğinizden emin misiniz?")) {
      deleteMutation.mutate(id);
    }
  };

  const handleOrderChange = async (activity: ActivityData, direction: "up" | "down") => {
    const currentIndex = activities?.findIndex(a => a.id === activity.id) || 0;
    const newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
    
    if (!activities || newIndex < 0 || newIndex >= activities.length) return;
    
    const otherActivity = activities[newIndex];
    
    // Swap display orders
    await updateMutation.mutateAsync({
      id: activity.id,
      data: { ...activity, displayOrder: otherActivity.displayOrder }
    });
    
    await updateMutation.mutateAsync({
      id: otherActivity.id,
      data: { ...otherActivity, displayOrder: activity.displayOrder }
    });
  };

  if (isLoading) {
    return (
      <AdminLayout title="Son Faaliyetler">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-border" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <>
      <Helmet>
        <title>Son Faaliyetler Yönetimi | Admin</title>
      </Helmet>
      
      <AdminLayout title="Son Faaliyetler Yönetimi">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Son Faaliyetler
                </CardTitle>
                <CardDescription>
                  Ana sayfada görüntülenen son faaliyetleri yönetin
                </CardDescription>
              </div>
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="h-4 w-4 mr-2" />
                Yeni Faaliyet Ekle
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Sıra</TableHead>
                  <TableHead>Başlık</TableHead>
                  <TableHead>Kategori</TableHead>
                  <TableHead>Tarih</TableHead>
                  <TableHead className="text-center">Durum</TableHead>
                  <TableHead className="text-right">İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activities?.map((activity, index) => (
                  <TableRow key={activity.id}>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleOrderChange(activity, "up")}
                          disabled={index === 0}
                        >
                          <ArrowUp className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleOrderChange(activity, "down")}
                          disabled={index === activities.length - 1}
                        >
                          <ArrowDown className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{activity.title}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {activity.category}
                      </span>
                    </TableCell>
                    <TableCell>{activity.date || "-"}</TableCell>
                    <TableCell className="text-center">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        activity.isActive 
                          ? "bg-green-100 text-green-800" 
                          : "bg-gray-100 text-gray-800"
                      }`}>
                        {activity.isActive ? "Aktif" : "Pasif"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleOpenDialog(activity)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(activity.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!activities || activities.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      Henüz faaliyet eklenmemiş. Yeni faaliyet ekleyerek başlayın.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>
                  {editingActivity ? "Faaliyeti Düzenle" : "Yeni Faaliyet Ekle"}
                </DialogTitle>
                <DialogDescription>
                  Ana sayfada görüntülenecek faaliyet bilgilerini girin
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">
                      Başlık <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Faaliyet başlığı"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="category" className="flex items-center gap-2">
                      <Tag className="h-4 w-4" />
                      Kategori <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      placeholder="Örn: Eğitim, Operasyon, Etkinlik"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">
                    Açıklama <span className="text-destructive">*</span>
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Faaliyet açıklaması"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date" className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Tarih
                    </Label>
                    <Input
                      id="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      placeholder="Örn: 15 Şubat 2024"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="link" className="flex items-center gap-2">
                      <Link2 className="h-4 w-4" />
                      Detay Linki
                    </Label>
                    <Input
                      id="link"
                      value={formData.link}
                      onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                      placeholder="/photos veya /events/1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="imageUrl" className="flex items-center gap-2">
                    <Image className="h-4 w-4" />
                    Görsel URL
                  </Label>
                  <Input
                    id="imageUrl"
                    value={formData.imageUrl}
                    onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                  {formData.imageUrl && (
                    <div className="mt-2">
                      <img
                        src={formData.imageUrl}
                        alt="Önizleme"
                        className="w-32 h-20 object-cover rounded border"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="isActive"
                      checked={formData.isActive}
                      onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                    />
                    <Label htmlFor="isActive">Aktif</Label>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Label htmlFor="displayOrder">Sıra:</Label>
                    <Input
                      id="displayOrder"
                      type="number"
                      value={formData.displayOrder}
                      onChange={(e) => setFormData({ ...formData, displayOrder: Number(e.target.value) })}
                      className="w-20"
                    />
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  İptal
                </Button>
                <Button type="submit">
                  {editingActivity ? "Güncelle" : "Ekle"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
}