import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "@/components/admin/AdminLayout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Loader2, UserX } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

// User tipi
type User = {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  role: "major_admin" | "admin" | "user" | "banned";
  isAdmin: boolean;
  createdAt: string;
};

export default function AdminUsers() {
  const { toast } = useToast();
  const [userToBan, setUserToBan] = useState<User | null>(null);
  const [showBanDialog, setShowBanDialog] = useState(false);

  // Kullanıcıları çek
  const { data: users = [], isLoading, isError } = useQuery<User[]>({
    queryKey: ["/api/users"],
    staleTime: 10000, // 10 saniye
  });

  // Kullanıcı banlama mutasyonu
  const banUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest(`/api/users/${userId}/ban`, "POST");
    },
    onSuccess: () => {
      toast({
        title: "Kullanıcı banlandı",
        description: "Kullanıcı başarıyla banlandı.",
        variant: "default",
      });
      // Doğru query key ile önbelleği geçersiz kıl
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      // Oturum değişiklikleri için de önbelleği geçersiz kıl
      queryClient.invalidateQueries();
      setShowBanDialog(false);
      setUserToBan(null);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Kullanıcı banlanırken bir hata oluştu: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });
  
  // Kullanıcı yasağını kaldırma mutasyonu
  const unbanUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest(`/api/users/${userId}/unban`, "POST");
    },
    onSuccess: () => {
      toast({
        title: "Yasak kaldırıldı",
        description: "Kullanıcı yasağı başarıyla kaldırıldı.",
        variant: "default",
      });
      // Doğru query key ile önbelleği geçersiz kıl
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      // Oturum değişiklikleri için de önbelleği geçersiz kıl
      queryClient.invalidateQueries();
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Kullanıcı yasağı kaldırılırken bir hata oluştu: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const handleBanUser = (user: User) => {
    setUserToBan(user);
    setShowBanDialog(true);
  };

  const confirmBanUser = () => {
    if (userToBan) {
      banUserMutation.mutate(userToBan.id.toString());
    }
  };

  // Kullanıcı rolüne göre badge rengi
  const getRoleBadge = (role: string) => {
    switch (role) {
      case "major_admin":
        return <Badge className="bg-purple-600">Süper Yönetici</Badge>;
      case "admin":
        return <Badge className="bg-blue-600">Yönetici</Badge>;
      case "banned":
        return <Badge className="bg-red-600">Banlanmış</Badge>;
      default:
        return <Badge className="bg-green-600">Kullanıcı</Badge>;
    }
  };

  // Tarihi formatla
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("tr-TR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <AdminLayout title="Kullanıcı Yönetimi">
      {/* Son Kayıt Olan Kullanıcılar */}
      <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-sm border dark:border-gray-800 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold dark:text-white">Son Kayıt Olan Kullanıcılar</h2>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-4">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <span className="ml-2">Yükleniyor...</span>
          </div>
        ) : isError ? (
          <div className="text-center py-4 text-red-600 dark:text-red-400">
            <p>Kullanıcılar yüklenirken bir hata oluştu.</p>
          </div>
        ) : (
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
            {users.slice(0, 6).map((user) => (
              <div 
                key={user.id} 
                className="p-4 border dark:border-gray-700 rounded-lg flex items-start space-x-3"
              >
                <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-lg font-semibold text-gray-700 dark:text-gray-200">
                  {user.firstName[0]}{user.lastName[0]}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{user.firstName} {user.lastName}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
                  <div className="mt-1 flex items-center gap-2">
                    {getRoleBadge(user.role)}
                    <span className="text-xs text-gray-500">
                      {new Date(user.createdAt).toLocaleDateString("tr-TR")}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Tüm Kullanıcılar Tablosu */}
      <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-sm border dark:border-gray-800">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold dark:text-white">Tüm Kullanıcılar</h2>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2 text-lg">Kullanıcılar yükleniyor...</span>
          </div>
        ) : isError ? (
          <div className="text-center py-8 text-red-600 dark:text-red-400">
            <p>Kullanıcılar yüklenirken bir hata oluştu.</p>
            <Button
              onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] })}
              variant="outline"
              className="mt-2"
            >
              Tekrar dene
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Kullanıcı Adı</TableHead>
                  <TableHead>İsim Soyisim</TableHead>
                  <TableHead>E-posta</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>Kayıt Tarihi</TableHead>
                  <TableHead>İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.length > 0 ? (
                  users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.id}</TableCell>
                      <TableCell>{user.username}</TableCell>
                      <TableCell>
                        {user.firstName} {user.lastName}
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{getRoleBadge(user.role)}</TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                      <TableCell>
                        {user.role !== "major_admin" && user.role !== "banned" && (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleBanUser(user)}
                            className="flex items-center"
                          >
                            <UserX className="h-4 w-4 mr-1" />
                            Banla
                          </Button>
                        )}
                        {user.role === "banned" && (
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline" className="text-red-500 border-red-500">
                              Banlanmış
                            </Badge>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => unbanUserMutation.mutate(user.id.toString())}
                              className="border-green-500 text-green-500 hover:bg-green-50 hover:text-green-600"
                              disabled={unbanUserMutation.isPending}
                            >
                              {unbanUserMutation.isPending ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                "Yasağı Kaldır"
                              )}
                            </Button>
                          </div>
                        )}
                        {user.role === "major_admin" && (
                          <Badge variant="outline" className="text-purple-500 border-purple-500">
                            Yasaklanamaz
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4">
                      Hiç kullanıcı bulunamadı.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Banlama Onay Dialog */}
        <AlertDialog open={showBanDialog} onOpenChange={setShowBanDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Kullanıcı Banlama</AlertDialogTitle>
              <AlertDialogDescription>
                <span className="font-semibold text-red-600">
                  {userToBan?.firstName} {userToBan?.lastName}
                </span>{" "}
                adlı kullanıcıyı banlamak istediğinize emin misiniz? Bu işlem geri alınamaz.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={banUserMutation.isPending}>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmBanUser}
                disabled={banUserMutation.isPending}
                className="bg-red-600 hover:bg-red-700"
              >
                {banUserMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> İşlem yapılıyor...
                  </>
                ) : (
                  "Evet, Banla"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}