import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash, Calendar } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Switch } from "@/components/ui/switch";
import { 
  DonationMethod, 
  DonationCampaign,
  InsertDonationMethod,
  InsertDonationCampaign,
  insertDonationMethodSchema,
  insertDonationCampaignSchema
} from "@shared/schema";

// Donation Method Form Schema
const donationMethodFormSchema = insertDonationMethodSchema.extend({
  bankName: z.string().min(1, "Banka adı gereklidir"),
  accountName: z.string().min(1, "Hesap adı gereklidir"),
  iban: z.string().min(1, "IBAN gereklidir"),
  logoUrl: z.string().optional().nullable(),
});

type DonationMethodFormValues = z.infer<typeof donationMethodFormSchema>;

// Donation Campaign Form Schema
const donationCampaignFormSchema = insertDonationCampaignSchema.extend({
  title: z.string().min(1, "Başlık gereklidir"),
  description: z.string().min(1, "Açıklama gereklidir"),
  targetAmount: z.coerce.number().optional().or(z.string().transform(s => s === "" ? undefined : Number(s))),
  currentAmount: z.coerce.number().optional().or(z.string().transform(s => s === "" ? undefined : Number(s))),
  endDate: z.string().optional(),
  isActive: z.boolean().default(true),
});

type DonationCampaignFormValues = z.infer<typeof donationCampaignFormSchema>;

export default function AdminDonationsPage() {
  const [activeTab, setActiveTab] = useState("methods");
  const [editingMethodId, setEditingMethodId] = useState<number | null>(null);
  const [editingCampaignId, setEditingCampaignId] = useState<number | null>(null);
  const [methodDialogOpen, setMethodDialogOpen] = useState(false);
  const [campaignDialogOpen, setCampaignDialogOpen] = useState(false);
  const { toast } = useToast();

  // Fetch donation methods and campaigns
  const { data: donationMethods = [] } = useQuery<DonationMethod[]>({
    queryKey: ["/api/donation/methods"],
  });

  const { data: donationCampaigns = [] } = useQuery<DonationCampaign[]>({
    queryKey: ["/api/donation/campaigns"],
  });

  // Method form
  const methodForm = useForm<DonationMethodFormValues>({
    resolver: zodResolver(donationMethodFormSchema),
    defaultValues: {
      bankName: "",
      accountName: "",
      iban: "",
      branchCode: "",
      accountNumber: "",
      currency: "TRY",
      description: "",
      logoUrl: "",
    },
  });

  // Campaign form
  const campaignForm = useForm<DonationCampaignFormValues>({
    resolver: zodResolver(donationCampaignFormSchema),
    defaultValues: {
      title: "",
      description: "",
      targetAmount: undefined,
      currentAmount: undefined,
      endDate: undefined,
      imageUrl: "",
      isActive: true,
    },
  });

  // Create donation method mutation
  const createMethodMutation = useMutation({
    mutationFn: async (method: InsertDonationMethod) => {
      const res = await apiRequest("POST", "/api/donation/methods", method);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donation/methods"] });
      setMethodDialogOpen(false);
      methodForm.reset();
      toast({
        title: "Bağış yöntemi eklendi",
        description: "Yeni bağış yöntemi başarıyla eklendi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `Bağış yöntemi eklenirken bir hata oluştu: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update donation method mutation
  const updateMethodMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertDonationMethod }) => {
      const res = await apiRequest("PUT", `/api/donation/methods/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donation/methods"] });
      setMethodDialogOpen(false);
      methodForm.reset();
      setEditingMethodId(null);
      toast({
        title: "Bağış yöntemi güncellendi",
        description: "Bağış yöntemi başarıyla güncellendi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `Bağış yöntemi güncellenirken bir hata oluştu: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete donation method mutation
  const deleteMethodMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/donation/methods/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donation/methods"] });
      toast({
        title: "Bağış yöntemi silindi",
        description: "Bağış yöntemi başarıyla silindi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `Bağış yöntemi silinirken bir hata oluştu: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Create donation campaign mutation
  const createCampaignMutation = useMutation({
    mutationFn: async (campaign: InsertDonationCampaign) => {
      const res = await apiRequest("POST", "/api/donation/campaigns", campaign);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donation/campaigns"] });
      setCampaignDialogOpen(false);
      campaignForm.reset();
      toast({
        title: "Bağış kampanyası eklendi",
        description: "Yeni bağış kampanyası başarıyla eklendi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `Bağış kampanyası eklenirken bir hata oluştu: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update donation campaign mutation
  const updateCampaignMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertDonationCampaign }) => {
      const res = await apiRequest("PUT", `/api/donation/campaigns/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donation/campaigns"] });
      setCampaignDialogOpen(false);
      campaignForm.reset();
      setEditingCampaignId(null);
      toast({
        title: "Bağış kampanyası güncellendi",
        description: "Bağış kampanyası başarıyla güncellendi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `Bağış kampanyası güncellenirken bir hata oluştu: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete donation campaign mutation
  const deleteCampaignMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/donation/campaigns/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donation/campaigns"] });
      toast({
        title: "Bağış kampanyası silindi",
        description: "Bağış kampanyası başarıyla silindi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `Bağış kampanyası silinirken bir hata oluştu: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle method form submission
  function onMethodSubmit(values: DonationMethodFormValues) {
    console.log("Submitting method values:", values);
    if (editingMethodId) {
      updateMethodMutation.mutate({ id: editingMethodId, data: values });
    } else {
      createMethodMutation.mutate(values);
    }
  }

  // Handle campaign form submission
  function onCampaignSubmit(values: DonationCampaignFormValues) {
    // Handle date conversion explicitly before submission
    // and convert numeric values to strings for API compatibility
    const formattedValues = {
      ...values,
      targetAmount: values.targetAmount !== undefined ? String(values.targetAmount) : undefined,
      currentAmount: values.currentAmount !== undefined ? String(values.currentAmount) : undefined,
      // Ensure endDate is sent as a string in ISO format if it exists
      endDate: values.endDate ? (typeof values.endDate === 'string' ? values.endDate : undefined) : undefined,
    };

    console.log("Submitting form values:", formattedValues);

    if (editingCampaignId) {
      updateCampaignMutation.mutate({ id: editingCampaignId, data: formattedValues });
    } else {
      createCampaignMutation.mutate(formattedValues);
    }
  }

  // Edit donation method
  function editMethod(method: DonationMethod) {
    setEditingMethodId(method.id);
    methodForm.reset({
      bankName: method.bankName,
      accountName: method.accountName,
      iban: method.iban,
      branchCode: method.branchCode || "",
      accountNumber: method.accountNumber || "",
      currency: method.currency || "TRY",
      description: method.description || "",
      logoUrl: method.logoUrl || "",
    });
    setMethodDialogOpen(true);
  }

  // Edit donation campaign
  function editCampaign(campaign: DonationCampaign) {
    console.log("Editing campaign:", campaign);
    setEditingCampaignId(campaign.id);
    campaignForm.reset({
      title: campaign.title,
      description: campaign.description,
      targetAmount: campaign.targetAmount ? Number(campaign.targetAmount) : undefined,
      currentAmount: campaign.currentAmount ? Number(campaign.currentAmount) : undefined,
      endDate: campaign.endDate || "",
      imageUrl: campaign.imageUrl || "",
      isActive: campaign.isActive || true,
    });
    setCampaignDialogOpen(true);
  }

  // Format currency
  function formatCurrency(amount: number | string | undefined): string {
    if (!amount) return "0 TL";
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(Number(amount));
  }

  return (
    <AdminLayout title="Bağışlar">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-6 dark:bg-gray-800 dark:text-gray-200">
          <TabsTrigger 
            value="methods"
            className="dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white dark:hover:bg-gray-700/80"
          >
            Bağış Yöntemleri
          </TabsTrigger>
          <TabsTrigger 
            value="campaigns"
            className="dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white dark:hover:bg-gray-700/80"
          >
            Bağış Kampanyaları
          </TabsTrigger>
        </TabsList>

        {/* Donation Methods Tab */}
        <TabsContent value="methods">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold">Bağış Yöntemleri</h2>
            <Dialog open={methodDialogOpen} onOpenChange={setMethodDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => {
                  setEditingMethodId(null);
                  methodForm.reset({
                    bankName: "",
                    accountName: "",
                    iban: "",
                    branchCode: "",
                    accountNumber: "",
                    currency: "TRY",
                    description: "",
                    logoUrl: "",
                  });
                }}>
                  <Plus className="h-4 w-4 mr-2" /> Bağış Yöntemi Ekle
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>
                    {editingMethodId ? "Bağış Yöntemini Düzenle" : "Yeni Bağış Yöntemi Ekle"}
                  </DialogTitle>
                  <DialogDescription>
                    Bağış yöntemi bilgilerini giriniz.
                  </DialogDescription>
                </DialogHeader>
                <Form {...methodForm}>
                  <form onSubmit={methodForm.handleSubmit(onMethodSubmit)} className="space-y-4">
                    <FormField
                      control={methodForm.control}
                      name="bankName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Banka Adı</FormLabel>
                          <FormControl>
                            <Input placeholder="Banka adı giriniz" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={methodForm.control}
                      name="logoUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Banka Logosu URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://example.com/bank-logo.png" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormDescription>
                            Bankanın logo görseli için URL adresi (Örn: Ziraat veya İş Bankası logosu)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={methodForm.control}
                      name="accountName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hesap Adı</FormLabel>
                          <FormControl>
                            <Input placeholder="Hesap adı giriniz" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={methodForm.control}
                      name="iban"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>IBAN</FormLabel>
                          <FormControl>
                            <Input placeholder="IBAN giriniz" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={methodForm.control}
                        name="branchCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Şube Kodu</FormLabel>
                            <FormControl>
                              <Input placeholder="Şube kodu" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={methodForm.control}
                        name="accountNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hesap No</FormLabel>
                            <FormControl>
                              <Input placeholder="Hesap numarası" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={methodForm.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Para Birimi</FormLabel>
                          <FormControl>
                            <Input placeholder="TRY" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={methodForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Açıklama</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Açıklama giriniz" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <DialogFooter>
                      <Button type="submit" disabled={methodForm.formState.isSubmitting || createMethodMutation.isPending || updateMethodMutation.isPending}>
                        {editingMethodId ? "Güncelle" : "Ekle"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-md shadow dark:shadow-gray-700">
            <Table>
              <TableHeader>
                <TableRow className="dark:border-gray-700">
                  <TableHead className="dark:text-gray-200">Banka</TableHead>
                  <TableHead className="dark:text-gray-200">Hesap Adı</TableHead>
                  <TableHead className="dark:text-gray-200">IBAN</TableHead>
                  <TableHead className="dark:text-gray-200">Açıklama</TableHead>
                  <TableHead className="text-right dark:text-gray-200">İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {donationMethods.length > 0 ? (
                  donationMethods.map((method) => (
                    <TableRow key={method.id} className="dark:border-gray-700">
                      <TableCell className="font-medium dark:text-gray-200">
                        <div className="flex items-center gap-3">
                          {method.logoUrl ? (
                            <div className="h-12 w-24 rounded overflow-hidden flex-shrink-0 bg-white p-1">
                              <img 
                                src={method.logoUrl} 
                                alt={`${method.bankName} logo`} 
                                className="h-full w-full object-contain"
                                onError={(e) => {
                                  // Hide broken images
                                  e.currentTarget.style.display = 'none';
                                }}
                              />
                            </div>
                          ) : null}
                          {method.bankName}
                        </div>
                      </TableCell>
                      <TableCell className="dark:text-gray-200">{method.accountName}</TableCell>
                      <TableCell className="font-mono text-sm dark:text-gray-200">{method.iban}</TableCell>
                      <TableCell className="dark:text-gray-200">{method.description}</TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => editMethod(method)}
                          className="dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => {
                            if (window.confirm("Bu bağış yöntemini silmek istediğinize emin misiniz?")) {
                              deleteMethodMutation.mutate(method.id);
                            }
                          }}
                          className="dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow className="dark:border-gray-700">
                    <TableCell colSpan={5} className="text-center py-6 text-gray-500 dark:text-gray-400">
                      Henüz bir bağış yöntemi eklenmemiş.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* Donation Campaigns Tab */}
        <TabsContent value="campaigns">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold">Bağış Kampanyaları</h2>
            <Dialog open={campaignDialogOpen} onOpenChange={setCampaignDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => {
                  setEditingCampaignId(null);
                  campaignForm.reset({
                    title: "",
                    description: "",
                    targetAmount: undefined,
                    currentAmount: undefined,
                    endDate: "",
                    imageUrl: "",
                    isActive: true,
                  });
                }}>
                  <Plus className="h-4 w-4 mr-2" /> Bağış Kampanyası Ekle
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>
                    {editingCampaignId ? "Bağış Kampanyasını Düzenle" : "Yeni Bağış Kampanyası Ekle"}
                  </DialogTitle>
                  <DialogDescription>
                    Bağış kampanyası bilgilerini giriniz.
                  </DialogDescription>
                </DialogHeader>
                <Form {...campaignForm}>
                  <form onSubmit={campaignForm.handleSubmit(onCampaignSubmit)} className="space-y-4">
                    <FormField
                      control={campaignForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Başlık</FormLabel>
                          <FormControl>
                            <Input placeholder="Kampanya başlığı" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={campaignForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Açıklama</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Kampanya açıklaması" {...field} rows={3} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={campaignForm.control}
                        name="targetAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hedef Tutar (TL)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="Hedef tutar" 
                                {...field} 
                                value={field.value || ""} 
                                onChange={(e) => {
                                  const value = e.target.value ? parseFloat(e.target.value) : undefined;
                                  field.onChange(value);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={campaignForm.control}
                        name="currentAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Toplanan Tutar (TL)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="Mevcut tutar" 
                                {...field} 
                                value={field.value || ""} 
                                onChange={(e) => {
                                  const value = e.target.value ? parseFloat(e.target.value) : undefined;
                                  field.onChange(value);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={campaignForm.control}
                        name="endDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bitiş Tarihi</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input 
                                  type="date" 
                                  value={field.value || ''}
                                  onChange={(e) => {
                                    // Keep the value as a simple string
                                    field.onChange(e.target.value || '');
                                  }}
                                  onBlur={field.onBlur}
                                  name={field.name}
                                  ref={field.ref}
                                />
                                <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={campaignForm.control}
                        name="isActive"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                            <div className="space-y-0.5">
                              <FormLabel>Aktif</FormLabel>
                              <FormDescription>
                                Kampanyayı aktif veya pasif yapın
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={campaignForm.control}
                      name="imageUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Görsel URL'i</FormLabel>
                          <FormControl>
                            <Input placeholder="https://example.com/image.jpg" {...field} />
                          </FormControl>
                          <FormDescription>
                            Kampanya kapak görseli için bir URL girin (örn. Unsplash)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <DialogFooter>
                      <Button type="submit" disabled={campaignForm.formState.isSubmitting || createCampaignMutation.isPending || updateCampaignMutation.isPending}>
                        {editingCampaignId ? "Güncelle" : "Ekle"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {donationCampaigns.length > 0 ? (
              donationCampaigns.map((campaign) => (
                <Card key={campaign.id} className={`dark:bg-gray-800 dark:border-gray-700 ${!campaign.isActive ? "opacity-70" : ""}`}>
                  {campaign.imageUrl && (
                    <div className="relative aspect-video w-full overflow-hidden">
                      <img 
                        src={campaign.imageUrl} 
                        alt={campaign.title} 
                        className="h-full w-full object-cover"
                      />
                      {!campaign.isActive && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                          <span className="text-white font-semibold text-lg">Pasif Kampanya</span>
                        </div>
                      )}
                    </div>
                  )}
                  <CardHeader className="dark:border-gray-700">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="dark:text-gray-100">{campaign.title}</CardTitle>
                        <CardDescription className="dark:text-gray-300">{campaign.description}</CardDescription>
                      </div>
                      <div className="flex">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => editCampaign(campaign)}
                          className="dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => {
                            if (window.confirm("Bu kampanyayı silmek istediğinize emin misiniz?")) {
                              deleteCampaignMutation.mutate(campaign.id);
                            }
                          }}
                          className="dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4 dark:border-gray-700">
                    {(campaign.currentAmount !== undefined && campaign.targetAmount !== undefined) && (
                      <>
                        <div className="flex justify-between text-sm dark:text-gray-200">
                          <span>Toplanan: {formatCurrency(campaign.currentAmount)}</span>
                          <span>Hedef: {formatCurrency(campaign.targetAmount)}</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                          <div 
                            className="bg-secondary h-2.5 rounded-full transition-all duration-300" 
                            style={{ width: `${Math.min((Number(campaign.currentAmount) / Number(campaign.targetAmount)) * 100, 100)}%` }}
                          ></div>
                        </div>
                      </>
                    )}
                    {campaign.endDate && (
                      <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        Son tarih: {new Date(campaign.endDate).toLocaleDateString('tr-TR')}
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="bg-secondary/5 dark:bg-gray-700/20 dark:border-t dark:border-gray-700 flex justify-between">
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {campaign.isActive ? "Aktif Kampanya" : "Pasif Kampanya"}
                    </span>
                  </CardFooter>
                </Card>
              ))
            ) : (
              <div className="col-span-2 text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-gray-500 dark:text-gray-400">Henüz bir bağış kampanyası eklenmemiş.</p>
                <Button className="mt-4" onClick={() => setCampaignDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" /> Kampanya Ekle
                </Button>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}