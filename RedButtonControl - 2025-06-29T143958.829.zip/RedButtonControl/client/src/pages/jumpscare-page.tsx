import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { useLocation } from "wouter";
import "./jumpscare-page.css";

export default function JumpscarePage() {
  const [, setLocation] = useLocation();
  const [showRedText, setShowRedText] = useState(false);
  
  // Record the attempted username in admin logs
  useEffect(() => {
    const attemptedUsername = sessionStorage.getItem('attempted_username') || 'unknown';
    
    // Log the attempt
    fetch('/api/security-log', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'unauthorized_admin_access_attempt',
        details: `Attempted to access admin account: ${attemptedUsername}`,
        ipAddress: 'captured on server',
      })
    }).catch(err => console.error('Failed to log security event:', err));
    
    // Clear the attempted username
    sessionStorage.removeItem('attempted_username');
    
    // Show red warning text immediately for better user experience
    setShowRedText(true);
    
    // Redirect back to login after the jumpscare (adjust timing as needed)
    const redirectTimer = setTimeout(() => {
      setLocation('/auth');
    }, 6000); // 6 seconds for jumpscare effect
    
    return () => clearTimeout(redirectTimer);
  }, [setLocation]);
  
  // No longer need handleImageError function as we're using text warnings
  
  // Try to play video with sound and also show text warnings
  useEffect(() => {
    // Show text warning immediately (this will always show even if video plays)
    setShowRedText(true);
    
    // Try to play the video after a short delay
    setTimeout(() => {
      const video = document.querySelector('video') as HTMLVideoElement;
      if (video) {
        // Make video visible
        video.style.display = 'block';
        
        video.muted = false;
        // Try to play with sound
        video.play()
          .then(() => console.log("Video playing successfully"))
          .catch(err => console.error("Could not play video with sound:", err));
      }
    }, 300);
  }, []);
  
  return (
    <>
      <Helmet>
        <title>Security Alert</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>
      
      <div className="jumpscare-container">
        {/* Container for the jumpscare video */}
        {/* Video container with the jumpscare video */}
        <div className="video-container">
          <video 
            className="jumpscare-video"
            autoPlay 
            loop
            playsInline
            src="/xoxoxo.mp4" // Try the root path where we know the video exists
            onError={(e) => {
              console.error("Video failed to load", e);
              // Video element already hidden by default style
              const target = e.target as HTMLVideoElement;
              target.style.display = 'none';
            }}
          />
        </div>
        
        {/* Warning text - always show this on error or after delay */}
        {showRedText && (
          <div className="security-warning">
            <h1>UNAUTHORIZED ACCESS ATTEMPT</h1>
            <p>This incident has been logged and reported.</p>
            <p>Your IP and device information have been recorded.</p>
          </div>
        )}
      </div>
    </>
  );
}