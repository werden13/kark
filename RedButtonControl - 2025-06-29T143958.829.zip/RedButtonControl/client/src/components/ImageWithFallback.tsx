import React, { useState, useEffect } from 'react';
import { ImageOff } from 'lucide-react';

interface ImageWithFallbackProps {
  src: string;
  alt: string;
  className?: string;
  fallbackClassName?: string;
  onError?: () => void;
}

export default function ImageWithFallback({ 
  src, 
  alt, 
  className = '', 
  fallbackClassName = '',
  onError 
}: ImageWithFallbackProps) {
  const [imgSrc, setImgSrc] = useState<string>(src);
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setImgSrc(src);
    setHasError(false);
    setIsLoading(true);
  }, [src]);

  // Convert common image hosting URLs to direct image URLs
  const getDirectImageUrl = (url: string): string => {
    if (!url) return '';
    
    // ImgBB - convert page URL to direct image URL
    if (url.includes('ibb.co/')) {
      // Extract image ID from URL like https://ibb.co/7xCYFyGG
      const matches = url.match(/ibb\.co\/([a-zA-Z0-9]+)/);
      if (matches && matches[1]) {
        // Try common ImgBB direct URL patterns
        return `https://i.ibb.co/${matches[1]}.jpg`;
      }
    }
    
    // Imgur - convert page URL to direct image URL
    if (url.includes('imgur.com/') && !url.includes('i.imgur.com')) {
      const matches = url.match(/imgur\.com\/([a-zA-Z0-9]+)/);
      if (matches && matches[1]) {
        return `https://i.imgur.com/${matches[1]}.jpg`;
      }
    }
    
    // Google Drive - convert sharing URL to direct image URL
    if (url.includes('drive.google.com')) {
      const matches = url.match(/\/d\/([a-zA-Z0-9-_]+)/);
      if (matches && matches[1]) {
        return `https://drive.google.com/uc?export=view&id=${matches[1]}`;
      }
    }
    
    // Dropbox - convert sharing URL to direct image URL
    if (url.includes('dropbox.com')) {
      return url.replace('?dl=0', '?raw=1').replace('www.dropbox.com', 'dl.dropboxusercontent.com');
    }
    
    return url;
  };

  const handleImageError = () => {
    // If the direct URL fails, try with different extensions
    const baseUrl = imgSrc.replace(/\.(jpg|jpeg|png|gif|webp)$/i, '');
    const extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
    const currentExtIndex = extensions.findIndex(ext => imgSrc.toLowerCase().endsWith(ext));
    
    if (currentExtIndex !== -1 && currentExtIndex < extensions.length - 1) {
      // Try next extension
      setImgSrc(baseUrl + extensions[currentExtIndex + 1]);
    } else {
      // All extensions tried, show error
      setHasError(true);
      setIsLoading(false);
      if (onError) onError();
    }
  };

  const processedUrl = getDirectImageUrl(imgSrc);

  if (hasError || !src) {
    return (
      <div className={`flex items-center justify-center bg-gray-100 text-gray-400 ${fallbackClassName || className}`}>
        <ImageOff className="w-12 h-12" />
      </div>
    );
  }

  return (
    <>
      {isLoading && (
        <div className={`flex items-center justify-center bg-gray-100 animate-pulse ${className}`}>
          <div className="w-full h-full bg-gray-200"></div>
        </div>
      )}
      <img
        src={processedUrl}
        alt={alt}
        className={`${className} ${isLoading ? 'hidden' : ''}`}
        onError={handleImageError}
        onLoad={() => setIsLoading(false)}
      />
    </>
  );
}