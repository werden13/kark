import { Link } from "wouter";
import { Album } from "@shared/schema";
import ImageWithFallback from "@/components/ImageWithFallback";

interface PhotoAlbumProps {
  album: Album & { photos: { id: number; filePath: string }[] };
  onPhotoClick: (photoIndex: number, albumId: number) => void;
}

export default function PhotoAlbum({ album, onPhotoClick }: PhotoAlbumProps) {
  // Display only up to 4 photos in preview
  const previewPhotos = album.photos.slice(0, 4);
  const remainingCount = album.photos.length - 4;
  
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md">
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-2">{album.title}</h3>
        <p className="text-primary mb-4">{album.description}</p>
      </div>
      
      <div className="grid grid-cols-2 gap-1">
        {previewPhotos.map((photo, index) => (
          <div 
            key={photo.id} 
            className={`relative ${index === 3 && remainingCount > 0 ? "relative" : ""}`}
            onClick={() => onPhotoClick(index, album.id)}
          >
            <ImageWithFallback 
              src={photo.filePath} 
              alt={`${album.title} ${index + 1}`} 
              className="w-full h-32 object-cover gallery-item"
              fallbackClassName="w-full h-32"
            />
            
            {index === 3 && remainingCount > 0 && (
              <div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center">
                <span className="text-white font-medium">+{remainingCount} Fotoğraf</span>
              </div>
            )}
          </div>
        ))}
        
        {/* Fill empty slots with placeholders if needed */}
        {previewPhotos.length < 4 && Array.from({ length: 4 - previewPhotos.length }).map((_, i) => (
          <div key={`placeholder-${i}`} className="w-full h-32 bg-gray-100"></div>
        ))}
      </div>
      
      <div className="p-4">
        <Link href={`/photos/${album.id}`} className="text-secondary hover:underline font-medium">
          Tüm Albümü Gör →
        </Link>
      </div>
    </div>
  );
}
