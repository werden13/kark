import { Loader2 } from "lucide-react";

interface LoadingSpinnerProps {
  size?: number;
  className?: string;
  variant?: "default" | "primary" | "secondary";
}

export function LoadingSpinner({ 
  size = 24, 
  className = "", 
  variant = "default" 
}: LoadingSpinnerProps) {
  const variantClasses = {
    default: "text-primary",
    primary: "text-primary",
    secondary: "text-secondary"
  };
  
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <Loader2 
        className={`h-${size} w-${size} animate-spin ${variantClasses[variant]}`} 
      />
    </div>
  );
}

export function PageLoader() {
  return (
    <div className="fixed inset-0 bg-background bg-opacity-70 flex items-center justify-center z-50 backdrop-blur-sm animate-fadeIn">
      <div className="bg-card p-8 rounded-lg shadow-lg flex flex-col items-center space-y-4 animate-slideUp">
        <div className="relative">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <div className="absolute inset-0 h-12 w-12 rounded-full border-t-2 border-primary opacity-20"></div>
        </div>
        <p className="text-lg font-medium text-foreground">Yükleniyor...</p>
        <div className="w-48 h-1 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-primary animate-pulse rounded-full" style={{width: '30%'}}></div>
        </div>
      </div>
    </div>
  );
}

export function ContentLoader() {
  return (
    <div className="w-full h-full min-h-[400px] flex flex-col items-center justify-center animate-fadeIn">
      <div className="relative">
        <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
        <div className="absolute inset-0 h-10 w-10 rounded-full border-t-2 border-primary opacity-20"></div>
      </div>
      <p className="text-muted-foreground animate-pulse">İçerik yükleniyor...</p>
      <div className="mt-4 flex space-x-2">
        {[0, 1, 2].map((i) => (
          <div 
            key={i}
            className="w-2 h-2 rounded-full bg-primary"
            style={{ 
              animationDelay: `${i * 0.2}s`,
              animation: "pulse 1.5s infinite" 
            }}
          />
        ))}
      </div>
    </div>
  );
}

// Add a sectional content loader for smaller areas
export function SectionLoader() {
  return (
    <div className="w-full py-8 flex flex-col items-center justify-center animate-fadeIn">
      <div className="flex space-x-2 mb-2">
        {[0, 1, 2].map((i) => (
          <div 
            key={i}
            className="w-1.5 h-1.5 rounded-full bg-primary"
            style={{ 
              animationDelay: `${i * 0.15}s`,
              animation: "pulse 1.5s infinite" 
            }}
          />
        ))}
      </div>
      <p className="text-sm text-muted-foreground">Yükleniyor</p>
    </div>
  );
}