import { Skeleton } from "@/components/ui/skeleton";

export function CardSkeleton() {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden animate-fadeIn">
      <Skeleton className="h-48 w-full animate-pulse" />
      <div className="p-6 space-y-4">
        <Skeleton className="h-6 w-3/4" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
        <Skeleton className="h-10 w-1/3 mt-4" />
      </div>
    </div>
  );
}

export function EventCardSkeleton() {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden animate-fadeIn">
      <Skeleton className="h-48 w-full animate-pulse" />
      <div className="p-4 space-y-3">
        <Skeleton className="h-5 w-2/3" />
        <div className="flex space-x-2">
          <Skeleton className="h-4 w-1/4" />
          <Skeleton className="h-4 w-1/4" />
        </div>
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-10 w-1/2 mt-2" />
      </div>
    </div>
  );
}

export function TeamMemberSkeleton() {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden animate-fadeIn">
      <Skeleton className="h-56 w-full rounded-t-lg animate-pulse" /> {/* Profile picture */}
      <div className="p-4 text-center space-y-2">
        <Skeleton className="h-5 w-3/5 mx-auto" /> {/* Name */}
        <Skeleton className="h-4 w-4/5 mx-auto" /> {/* Position */}
        <Skeleton className="h-3 w-1/2 mx-auto" /> {/* Contact */}
      </div>
    </div>
  );
}

export function GridSkeleton({ count = 6 }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
      {Array(count).fill(0).map((_, index) => (
        <div key={index} style={{ animationDelay: `${index * 0.1}s` }}>
          <CardSkeleton />
        </div>
      ))}
    </div>
  );
}

export function EventGridSkeleton({ count = 6 }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
      {Array(count).fill(0).map((_, index) => (
        <div key={index} style={{ animationDelay: `${index * 0.1}s` }}>
          <EventCardSkeleton />
        </div>
      ))}
    </div>
  );
}

export function TeamGridSkeleton({ count = 6 }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
      {Array(count).fill(0).map((_, index) => (
        <div key={index} style={{ animationDelay: `${index * 0.1}s` }}>
          <TeamMemberSkeleton />
        </div>
      ))}
    </div>
  );
}