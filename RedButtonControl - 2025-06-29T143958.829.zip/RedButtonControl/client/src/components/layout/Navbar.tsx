import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import ThemeToggle from "@/components/theme/theme-toggle";



export default function Navbar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
    closeMobileMenu();
  };

  const navLinks = [
    { path: "/", label: "Anasayfa" },
    { path: "/archive", label: "Arşiv" },
    { path: "/about", label: "Hakkımızda" },
    { path: "/events", label: "Operasyonlar" },
    { path: "/videos", label: "Eğitim Videoları" },
    { path: "/photos", label: "Fotoğraf Galerisi" },
    { path: "/team", label: "Ekibimiz" },
    { path: "/donations", label: "Bağış Yap" },
    { path: "/contact", label: "İletişim" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-900 shadow-md dark:shadow-blue-900/20 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Theme Toggle */}
          <div className="absolute left-4 lg:left-8 z-10">
            <ThemeToggle />
          </div>
          
          <Link href="/" className="ml-10 md:ml-0 flex items-center gap-2">
            <img 
              src="/kark-logo.png" 
              alt="KARK Logo" 
              className="h-10 md:h-12 w-auto"
            />
            <span className="text-3xl font-bold">
              <span style={{ 
                color: '#FF0000', 
                textShadow: '2px 2px 0 #000', 
                WebkitTextStroke: '1px #000'
              }}>K</span>
              <span style={{ 
                color: '#FFFFFF', 
                textShadow: '2px 2px 0 #000', 
                WebkitTextStroke: '1px #000'
              }}>A</span>
              <span style={{ 
                color: '#FF0000', 
                textShadow: '2px 2px 0 #000', 
                WebkitTextStroke: '1px #000'
              }}>RK</span>
            </span>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            {navLinks.map((link) => (
              <Link 
                key={link.path}
                href={link.path} 
                className={cn(
                  "text-dark dark:text-gray-200 hover:text-primary dark:hover:text-red-400 font-medium transition-all duration-300",
                  location === link.path && "text-primary dark:text-red-400"
                )}
                onClick={closeMobileMenu}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          
          {/* Auth Buttons - Desktop */}
          <div className="hidden md:flex space-x-4">
            {user ? (
              <>
                {user.isAdmin && (
                  <Link href="/admin">
                    <Button variant="outline">Admin Panel</Button>
                  </Link>
                )}
                <Button variant="ghost" onClick={handleLogout} className="text-secondary">
                  Çıkış Yap
                </Button>
              </>
            ) : (
              <>
                <Link href="/auth" className="text-secondary hover:text-blue-700 font-medium flex items-center">
                  Giriş Yap
                </Link>
                <a href="/auth?action=register">
                  <Button>Kayıt Ol</Button>
                </a>
              </>
            )}
          </div>
          
          {/* Mobile Menu Button */}
          <Button 
            variant="ghost" 
            className="md:hidden" 
            onClick={toggleMobileMenu}
            aria-label={isMobileMenuOpen ? "Menüyü Kapat" : "Menüyü Aç"}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
        
        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden pt-4 pb-2">
            <nav className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <Link 
                  key={link.path}
                  href={link.path} 
                  className={cn(
                    "text-dark dark:text-gray-200 hover:text-primary dark:hover:text-red-400 font-medium transition-colors duration-300",
                    location === link.path && "text-primary dark:text-red-400"
                  )}
                  onClick={closeMobileMenu}
                >
                  {link.label}
                </Link>
              ))}
              
              {/* Auth Links - Mobile */}
              <div className="flex flex-col space-y-2 pt-2">
                {user ? (
                  <>
                    {user.isAdmin && (
                      <Link href="/admin" onClick={closeMobileMenu}>
                        <Button variant="outline" className="w-full">Admin Panel</Button>
                      </Link>
                    )}
                    <Button variant="ghost" onClick={handleLogout} className="text-secondary">
                      Çıkış Yap
                    </Button>
                  </>
                ) : (
                  <>
                    <Link href="/auth" onClick={closeMobileMenu}>
                      <Button variant="secondary" className="w-full">Giriş Yap</Button>
                    </Link>
                    <Button 
                      className="w-full"
                      onClick={() => {
                        closeMobileMenu();
                        window.location.href = "/auth?action=register";
                      }}
                    >
                      Kayıt Ol
                    </Button>
                  </>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
