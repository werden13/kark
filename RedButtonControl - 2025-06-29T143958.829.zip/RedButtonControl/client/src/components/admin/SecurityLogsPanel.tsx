import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import { apiRequest } from "@/lib/queryClient";
import { Shield, FileText, Users, Calendar, Image, Settings, Heart, AlertTriangle, Info, Eye, Smartphone, Monitor, Tablet } from 'lucide-react';

interface AdminLog {
  id: number;
  userId: number;
  action: string;
  details?: string;
  ipAddress?: string;
  userAgent?: string;
  resourceType?: string;
  resourceId?: string;
  timestamp: string;
}

interface AdminLogsResponse {
  logs: AdminLog[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
  };
}

// Helper function to get resource icon
const getResourceIcon = (resourceType: string | null | undefined) => {
  switch (resourceType) {
    case 'events':
      return <Calendar className="h-4 w-4 text-blue-500" />;
    case 'media':
      return <Image className="h-4 w-4 text-purple-500" />;
    case 'team':
      return <Users className="h-4 w-4 text-green-500" />;
    case 'settings':
      return <Settings className="h-4 w-4 text-gray-500" />;
    case 'users':
      return <Users className="h-4 w-4 text-orange-500" />;
    case 'donations':
      return <Heart className="h-4 w-4 text-red-500" />;
    default:
      return <FileText className="h-4 w-4 text-gray-500" />;
  }
};

// Helper function to format action type
const formatAction = (action: string) => {
  if (action.startsWith('GET')) {
    return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Görüntüleme</Badge>;
  } else if (action.startsWith('POST')) {
    return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Ekleme</Badge>;
  } else if (action.startsWith('PUT') || action.startsWith('PATCH')) {
    return <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">Güncelleme</Badge>;
  } else if (action.startsWith('DELETE')) {
    return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Silme</Badge>;
  } else if (action.includes("unauthorized")) {
    return <Badge variant="destructive">Yetkisiz Erişim</Badge>;
  } else if (action.includes("İptal") || action.includes("iptal") || action.includes("cancel")) {
    return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">İptal</Badge>;
  }
  return <Badge variant="outline">{action}</Badge>;
};

// Helper to extract device info from user agent using basic parsing
const extractDeviceInfo = (userAgent?: string) => {
  if (!userAgent) return { 
    device: "Bilinmiyor", 
    browser: "Bilinmiyor", 
    os: "Bilinmiyor",
    deviceType: "unknown"
  };
  
  // Device type detection
  let deviceType = "desktop";
  if (userAgent.includes("Android") || userAgent.includes("iPhone") || userAgent.includes("Mobile")) {
    deviceType = "mobile";
  } else if (userAgent.includes("iPad") || userAgent.includes("Tablet")) {
    deviceType = "tablet";
  } else if (userAgent.includes("curl") || userAgent.includes("Wget")) {
    deviceType = "terminal";
  } else if (userAgent.includes("Postman")) {
    deviceType = "api_client";
  }
  
  // Browser detection
  let browser = "Bilinmiyor";
  if (userAgent.includes("Firefox")) {
    browser = "Firefox";
  } else if (userAgent.includes("Chrome") && userAgent.includes("Edg")) {
    browser = "Edge";
  } else if (userAgent.includes("Chrome") && userAgent.includes("Safari")) {
    browser = "Chrome";
  } else if (userAgent.includes("Safari") && !userAgent.includes("Chrome")) {
    browser = "Safari";
  } else if (userAgent.includes("Trident") || userAgent.includes("MSIE")) {
    browser = "Internet Explorer";
  } else if (userAgent.includes("Opera") || userAgent.includes("OPR")) {
    browser = "Opera";
  } else if (userAgent.includes("curl")) {
    browser = "curl";
  }
  
  // OS detection
  let os = "Bilinmiyor";
  if (userAgent.includes("Windows")) {
    os = "Windows";
    if (userAgent.includes("Windows NT 10.0")) os += " 10";
    else if (userAgent.includes("Windows NT 6.3")) os += " 8.1";
    else if (userAgent.includes("Windows NT 6.2")) os += " 8";
    else if (userAgent.includes("Windows NT 6.1")) os += " 7";
  } else if (userAgent.includes("Mac OS X")) {
    os = "macOS";
    // Extract version if available
    const macOSMatch = userAgent.match(/Mac OS X (\d+[._]\d+)/);
    if (macOSMatch && macOSMatch[1]) {
      os += " " + macOSMatch[1].replace("_", ".");
    }
  } else if (userAgent.includes("Linux")) {
    os = "Linux";
  } else if (userAgent.includes("Android")) {
    os = "Android";
    // Extract version if available
    const androidMatch = userAgent.match(/Android (\d+(\.\d+)*)/);
    if (androidMatch && androidMatch[1]) {
      os += " " + androidMatch[1];
    }
  } else if (userAgent.includes("iOS") || userAgent.includes("iPhone") || userAgent.includes("iPad")) {
    os = "iOS";
    // Extract version if available
    const iosMatch = userAgent.match(/OS (\d+[._]\d+)/);
    if (iosMatch && iosMatch[1]) {
      os += " " + iosMatch[1].replace("_", ".");
    }
  }
  
  // Map device type to Turkish names
  let device;
  switch(deviceType) {
    case "mobile":
      device = "Mobil";
      break;
    case "tablet":
      device = "Tablet";
      break;
    case "terminal":
      device = "Terminal/CLI";
      break;
    case "api_client":
      device = "API İstemcisi";
      break;
    default:
      device = "Masaüstü";
  }
  
  return { 
    device,
    browser,
    os,
    deviceType
  };
};

export default function SecurityLogsPanel() {
  const [limit, setLimit] = useState(10);
  const [offset, setOffset] = useState(0);
  const [resourceType, setResourceType] = useState<string>("all");
  const [selectedLog, setSelectedLog] = useState<AdminLog | null>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  
  const { data, isLoading, isError, refetch } = useQuery<AdminLogsResponse>({
    queryKey: ['/api/admin-logs', limit, offset, resourceType],
    refetchInterval: 2000, // Auto refresh every 2 seconds
    staleTime: 0, // Always consider data stale to force fresh fetch
    gcTime: 0, // Don't cache the data at all
    queryFn: async () => {
      const params = new URLSearchParams();
      params.append('limit', limit.toString());
      params.append('offset', offset.toString());
      if (resourceType !== 'all') {
        params.append('resourceType', resourceType);
      }
      
      const response = await apiRequest('GET', `/api/admin-logs?${params.toString()}`);
      const rawData = await response.json();
      
      // Transform snake_case DB fields to camelCase for frontend
      const logs = rawData.logs.map((log: any) => ({
        id: log.id,
        userId: log.user_id,
        action: log.action,
        details: log.details,
        ipAddress: log.ip_address,
        userAgent: log.user_agent,
        resourceType: log.resource_type,
        resourceId: log.resource_id,
        timestamp: log.timestamp
      }));
      
      return {
        logs,
        pagination: rawData.pagination
      };
    },
  });
  
  const handleNextPage = () => {
    if (data && offset + limit < data.pagination.total) {
      setOffset(offset + limit);
    }
  };

  const handlePrevPage = () => {
    if (offset - limit >= 0) {
      setOffset(offset - limit);
    }
  };
  
  const handleViewDetails = (log: AdminLog) => {
    setSelectedLog(log);
    setShowDetailsDialog(true);
  };
  
  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight mb-1">Güvenlik Kayıtları</h2>
            <p className="text-muted-foreground">Tüm yönetici aktivitelerinin güvenlik izlemeleri</p>
          </div>
          <Shield className="h-6 w-6 text-secondary" />
        </div>
        
        {/* Filter and Controls */}
        <div className="flex justify-between items-center">
          <Select value={resourceType} onValueChange={setResourceType}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Tüm Kaynaklar" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tüm Kaynaklar</SelectItem>
              <SelectItem value="events">Etkinlikler</SelectItem>
              <SelectItem value="media">Medya</SelectItem>
              <SelectItem value="team">Takım</SelectItem>
              <SelectItem value="settings">Ayarlar</SelectItem>
              <SelectItem value="sliders">Slider</SelectItem>
              <SelectItem value="users">Kullanıcılar</SelectItem>
              <SelectItem value="donations">Bağışlar</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handlePrevPage}
              disabled={offset === 0}
            >
              Önceki Sayfa
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleNextPage}
              disabled={offset + limit >= (data?.pagination.total || 0)}
            >
              Sonraki Sayfa
            </Button>
          </div>
        </div>
        
        {/* Logs Table */}
        <Card className="shadow-sm">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : isError ? (
              <Alert variant="destructive" className="m-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Hata</AlertTitle>
                <AlertDescription>Güvenlik kayıtları yüklenirken bir hata oluştu.</AlertDescription>
              </Alert>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="w-[50px]">ID</TableHead>
                      <TableHead className="w-[100px]">Kullanıcı</TableHead>
                      <TableHead className="w-[120px]">İşlem Tipi</TableHead>
                      <TableHead>İşlem Detayı</TableHead>
                      <TableHead className="w-[120px]">IP Adresi</TableHead>
                      <TableHead className="w-[120px]">Kaynak</TableHead>
                      <TableHead className="w-[160px]">Tarih</TableHead>
                      <TableHead className="w-[80px]">Detaylar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data?.logs.map((log) => (
                      <TableRow key={log.id} className="hover:bg-muted/30">
                        <TableCell className="font-medium">{log.id}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            {log.userId === 1 ? "Admin" : log.userId === 2 ? "Supermanager" : `Kullanıcı ${log.userId}`}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatAction(log.action)}</TableCell>
                        <TableCell className="max-w-[200px] truncate">
                          {log.action.includes("unauthorized") 
                            ? (log.details || "Yetkisiz erişim girişimi")
                            : (log.details || log.action)}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {log.ipAddress 
                            ? (log.ipAddress.length > 20 
                                ? log.ipAddress.split(',')[0].trim() + '...' 
                                : log.ipAddress)
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getResourceIcon(log.resourceType)}
                            <span>{log.resourceType || 'Diğer'}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {format(new Date(log.timestamp), 'dd.MM.yyyy HH:mm')}
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleViewDetails(log)}
                            title="Detayları Görüntüle"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {data?.logs.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                          <div className="flex flex-col items-center justify-center space-y-2">
                            <FileText className="h-8 w-8 text-muted" />
                            <p>Henüz kayıt bulunmuyor</p>
                            <p className="text-xs text-muted-foreground">Yönetici işlemleri burada gösterilecek</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
        
        <div className="text-sm text-muted-foreground text-center">
          Toplam <strong>{data?.pagination.total || 0}</strong> kayıttan <strong>{Math.min(data?.logs.length || 0, 1) + offset}</strong>-<strong>{Math.min(offset + limit, data?.pagination.total || 0)}</strong> arası gösteriliyor
        </div>
      </div>
      
      {/* Detailed Log Information Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Güvenlik Kaydı Detayı</DialogTitle>
            <DialogDescription>
              ID: {selectedLog?.id} • {selectedLog?.timestamp ? format(new Date(selectedLog.timestamp), 'dd.MM.yyyy HH:mm:ss') : ''}
            </DialogDescription>
          </DialogHeader>
          
          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold flex items-center gap-1.5">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    Kullanıcı Bilgisi
                  </h3>
                  <div className="bg-muted/50 p-3 rounded-md text-sm">
                    <p><strong>Kullanıcı ID:</strong> {selectedLog.userId}</p>
                    <p><strong>Kullanıcı:</strong> {selectedLog.userId === 1 ? "Admin" : selectedLog.userId === 2 ? "Supermanager" : `Kullanıcı ${selectedLog.userId}`}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold flex items-center gap-1.5">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    İşlem Bilgisi
                  </h3>
                  <div className="bg-muted/50 p-3 rounded-md text-sm">
                    <p><strong>İşlem:</strong> {selectedLog.action}</p>
                    <p><strong>Kaynak Türü:</strong> {selectedLog.resourceType || 'Genel'}</p>
                    <p><strong>Kaynak ID:</strong> {selectedLog.resourceId || '-'}</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-sm font-semibold flex items-center gap-1.5">
                  <Info className="h-4 w-4 text-muted-foreground" />
                  Teknik Detaylar
                </h3>
                <div className="bg-muted/50 p-3 rounded-md text-sm space-y-2">
                  <p className="font-medium text-red-600">
                    <strong>IP Adresi:</strong> {selectedLog.ipAddress || 'Bilinmiyor'}
                  </p>
                  
                  {selectedLog.userAgent && (
                    <>
                      <p className="border-t border-border pt-2 mt-2"><strong>Tam User Agent:</strong></p>
                      <p className="font-mono text-xs break-all">{selectedLog.userAgent}</p>
                      
                      <div className="mt-3 pt-2 border-t border-border">
                        <h4 className="text-sm font-semibold mb-2">Cihaz Bilgileri</h4>
                        {(() => {
                          const { 
                            device, 
                            browser, 
                            os, 
                            deviceType 
                          } = extractDeviceInfo(selectedLog.userAgent);
                          
                          // Get device icon
                          const DeviceIcon = () => {
                            switch(deviceType) {
                              case 'mobile':
                                return <Smartphone className="h-4 w-4 text-blue-600" />;
                              case 'tablet':
                                return <Tablet className="h-4 w-4 text-purple-600" />;
                              default:
                                return <Monitor className="h-4 w-4 text-gray-600" />;
                            }
                          };
                          
                          return (
                            <>
                              <div className="bg-amber-50 dark:bg-amber-950/20 p-3 rounded-md">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <div className="flex items-center gap-1.5 mb-1">
                                      <DeviceIcon />
                                      <p className="font-medium">{device}</p>
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <p className="font-medium">İşletim Sistemi</p>
                                    <p className="text-sm">{os}</p>
                                  </div>
                                </div>
                                
                                <div className="mt-3 pt-3 border-t border-border/30">
                                  <p className="font-medium">Tarayıcı Bilgisi</p>
                                  <p className="text-sm">{browser}</p>
                                </div>
                              </div>
                            </>
                          );
                        })()}
                      </div>
                    </>
                  )}
                  
                  {selectedLog.details && (
                    <div className="border-t border-border pt-2 mt-2">
                      <p><strong>Ek Detaylar:</strong></p>
                      <p className="whitespace-pre-wrap">{selectedLog.details}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}