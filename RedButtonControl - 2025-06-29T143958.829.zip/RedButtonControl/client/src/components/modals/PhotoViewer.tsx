import { useState, useEffect } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PhotoViewerProps {
  isOpen: boolean;
  photos: { id: number; filePath: string; title?: string }[];
  initialIndex: number;
  onClose: () => void;
}

export default function PhotoViewer({ 
  isOpen, 
  photos, 
  initialIndex = 0, 
  onClose 
}: PhotoViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  useEffect(() => {
    setCurrentIndex(initialIndex);
  }, [initialIndex, isOpen]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      
      // Add keyboard navigation
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
        if (e.key === 'ArrowLeft') prevPhoto();
        if (e.key === 'ArrowRight') nextPhoto();
      };
      
      window.addEventListener('keydown', handleKeyDown);
      
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [isOpen, onClose]);

  const nextPhoto = () => {
    if (photos.length <= 1) return;
    setCurrentIndex((prev) => (prev + 1) % photos.length);
  };

  const prevPhoto = () => {
    if (photos.length <= 1) return;
    setCurrentIndex((prev) => (prev - 1 + photos.length) % photos.length);
  };

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;
    
    if (isLeftSwipe) {
      nextPhoto();
    } else if (isRightSwipe) {
      prevPhoto();
    }
    
    setTouchStart(null);
    setTouchEnd(null);
  };

  // Close when clicking the background
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center"
      onClick={handleBackdropClick}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <Button 
        variant="ghost" 
        size="icon"
        className="absolute top-4 right-4 text-white hover:text-gray-300 focus:outline-none"
        onClick={onClose}
        aria-label="Close photo viewer"
      >
        <X className="h-6 w-6" />
      </Button>
      
      <div className="w-full max-w-4xl">
        <img 
          src={photos[currentIndex]?.filePath} 
          alt={photos[currentIndex]?.title || `Photo ${currentIndex + 1}`} 
          className="max-w-full max-h-[80vh] mx-auto object-contain"
        />
        
        {photos[currentIndex]?.title && (
          <p className="text-white text-center mt-4">{photos[currentIndex].title}</p>
        )}
      </div>
      
      {photos.length > 1 && (
        <>
          <Button 
            variant="outline" 
            size="icon"
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full hover:bg-opacity-70 transition"
            onClick={prevPhoto}
            aria-label="Previous photo"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full hover:bg-opacity-70 transition"
            onClick={nextPhoto}
            aria-label="Next photo"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
          
          <div className="absolute bottom-4 left-0 right-0 text-center text-white">
            {currentIndex + 1} / {photos.length}
          </div>
        </>
      )}
    </div>
  );
}
