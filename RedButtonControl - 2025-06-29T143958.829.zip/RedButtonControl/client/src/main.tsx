import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { HelmetProvider } from "react-helmet-async";

// Add Google Fonts
const linkElement = document.createElement('link');
linkElement.rel = 'stylesheet';
linkElement.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
document.head.appendChild(linkElement);

// Add title
const titleElement = document.createElement('title');
titleElement.textContent = 'KARK';
document.head.appendChild(titleElement);

// Add meta description
const metaDescElement = document.createElement('meta');
metaDescElement.name = 'description';
metaDescElement.content = 'Sanat, kültür ve eğitim alanında düzenlenen çeşitli etkinliklerle toplumsal gelişime katkı sağlıyoruz.';
document.head.appendChild(metaDescElement);

createRoot(document.getElementById("root")!).render(
  <HelmetProvider>
    <App />
  </HelmetProvider>
);
