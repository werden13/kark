import React from 'react';

/**
 * This file contains fixes for the admin panel issues
 * 
 * 1. Fix for SelectItem components with empty values
 * 2. Fix for "iptal" button translations and styling
 * 3. Fix for admin actions display
 */

// SelectItem component wrapper that ensures every item has a valid value prop
export const SafeSelectItem: React.FC<{
  value: string;
  children: React.ReactNode;
  className?: string;
}> = ({ value, children, className }) => {
  // Ensure value is never empty, use a fallback if needed
  const safeValue = value || "empty_value";
  
  return (
    <div className={className} data-value={safeValue}>
      {children}
    </div>
  );
};

// Button component for the cancel button with consistent styling
export const CancelButton: React.FC<{
  onClick: () => void;
  disabled?: boolean;
  className?: string;
}> = ({ onClick, disabled, className }) => {
  return (
    <button
      type="button"
      className={`bg-white text-gray-700 border border-gray-300 rounded-md px-4 py-2 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${className || ''}`}
      onClick={onClick}
      disabled={disabled}
    >
      İptal
    </button>
  );
};

// Function to format admin action types consistently
export const formatAdminAction = (action: string): { label: string; color: string } => {
  if (!action) return { label: 'Bilinmiyor', color: 'bg-gray-100 text-gray-700' };
  
  if (action.startsWith('GET')) {
    return { label: 'Görüntüleme', color: 'bg-blue-50 text-blue-700' };
  } else if (action.startsWith('POST')) {
    return { label: 'Ekleme', color: 'bg-green-50 text-green-700' };
  } else if (action.startsWith('PUT') || action.startsWith('PATCH')) {
    return { label: 'Güncelleme', color: 'bg-orange-50 text-orange-700' };
  } else if (action.startsWith('DELETE')) {
    return { label: 'Silme', color: 'bg-red-50 text-red-700' };
  } else if (action.includes('unauthorized')) {
    return { label: 'Yetkisiz Erişim', color: 'bg-red-100 text-red-700' };
  }
  
  return { label: action, color: 'bg-gray-100 text-gray-700' };
};