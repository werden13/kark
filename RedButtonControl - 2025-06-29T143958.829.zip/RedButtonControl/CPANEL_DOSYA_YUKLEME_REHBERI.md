# cPanel Dosya Yükleme Rehberi

## Dosya Yapısı Açıklaması

**Geliştirme Ortamında (Replit):**
- `package.json` - Tüm geliştirme bağımlılıklarını içeren dosya (mevcut)
- `package-cpanel.json` - cPanel için sadeleştirilmiş bağımlılıklar

**cPanel'e Yüklerken:**
- `package-cpanel.json` → `package.json` olarak yeniden adlandırılacak
- Böylece cPanel'de sadece gerekli bağımlılıklar yüklenecek

## Adım Adım Yükleme

### 1. Dosyaları Hazırlayın
**Bilgisayarınızda yeni bir klasör oluşturun ve içine şunları kopyalayın:**
- `server.js`
- `package-cpanel.json` → **Bilgisayarınızda `package.json` olarak kaydedin**
- `.env.example`
- `kark_complete_database_cpanel_fixed.sql`
- `client/` klasörü (tüm içeriğiyle)
- `public/` klasörü
- `data/` klasörü

**NOT:** Replit'teki orijinal `package.json` dosyasını almayın, sadece `package-cpanel.json` içeriğini alıp `package.json` adıyla kaydedin.

### 2. cPanel File Manager'da Yükleme
1. cPanel → File Manager'a gidin
2. Node.js uygulamanız için bir klasör oluşturun (örn: `kark-website`)
3. Bu klasöre girin

### 3. Dosyaları Yükleyin
1. Hazırladığınız tüm dosyaları yükleyin
2. Artık cPanel'de doğru `package.json` dosyanız var (sadeleştirilmiş versiyon)

### 4. .env Dosyasını Oluşturun
1. `.env.example` dosyasını kopyalayın
2. Adını `.env` yapın
3. İçindeki değerleri düzenleyin:
```
DB_TYPE=mysql
DB_HOST=localhost
DB_USER=mysite_karkuser
DB_PASSWORD=sizin_mysql_sifreniz
DB_NAME=mysite_kark
SESSION_SECRET=uzun-guvenli-bir-metin
```

## Sonuç Dosya Yapısı (cPanel'de):
```
kark-website/
├── server.js
├── package.json (package-cpanel.json'dan yeniden adlandırılmış)
├── .env (düzenlenmiş)
├── client/
│   └── (tüm frontend dosyaları)
├── public/
│   └── (statik dosyalar)
└── data/
    └── (JSON yedek dosyaları)
```

## Neden İki package.json?
- **Geliştirme ortamında**: Tam özellikli package.json (TypeScript, Vite, vs.)
- **cPanel'de**: Sadeleştirilmiş package.json (sadece Express ve temel bağımlılıklar)

Bu sayede cPanel'de gereksiz bağımlılıklar yüklenmez ve daha hızlı çalışır.