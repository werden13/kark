# Quick cPanel Setup Guide for KARK Website

## Files You Need for cPanel Deployment:

### 1. Main Server File
- **`server.js`** - Your main Node.js application file

### 2. Package Configuration
- **`package-cpanel.json`** - Rename this to `package.json` on your server
- Contains only essential dependencies for cPanel hosting

### 3. Database Setup
- **`kark_complete_database_cpanel_fixed.sql`** - Import this in phpMyAdmin
- Fixed version that doesn't include CREATE DATABASE commands

### 4. Environment Configuration
- **`.env.example`** - Copy to `.env` and update with your cPanel credentials

## Step-by-Step cPanel Deployment:

### Step 1: Create MySQL Database
1. Go to cPanel → **MySQL Databases**
2. Create database: `yoursite_kark` (use your cPanel prefix)
3. Create MySQL user with strong password
4. Add user to database with **ALL PRIVILEGES**

### Step 2: Import Database
1. Go to cPanel → **phpMyAdmin**
2. **Click on your database name** in left sidebar (e.g., `yoursite_kark`)
3. Click **Import** tab
4. Upload `kark_complete_database_cpanel_fixed.sql`
5. Click **Go** to import

### Step 3: Upload Files
1. Upload all files to your cPanel File Manager
2. Rename `package-cpanel.json` to `package.json`
3. Copy `.env.example` to `.env`
4. Edit `.env` with your database credentials:
   ```
   DB_TYPE=mysql
   DB_HOST=localhost
   DB_USER=yoursite_karkuser
   DB_PASSWORD=your_mysql_password
   DB_NAME=yoursite_kark
   SESSION_SECRET=your-random-secret-string
   ```

### Step 4: Setup Node.js App
1. Go to cPanel → **Node.js Selector**
2. Create new app:
   - **App Name**: `kark-website`
   - **Startup File**: `server.js`
   - **Application Root**: your app folder path
3. Install dependencies through the interface
4. Start the application

## Troubleshooting:

### Database Import Error: "No database selected"
- **Solution**: Make sure you click on your database name in phpMyAdmin sidebar BEFORE clicking Import

### App Lock Error: "Can't acquire lock"
- **Solution**: Use a unique app name in Node.js Selector, avoid names like "myapp"

### Dependencies Installation
- All required packages are listed in `package-cpanel.json`
- cPanel will automatically install them when you create the Node.js app

### Default Admin Login:
- **Username**: `supermanager`
- **Password**: `admin123`

## File Structure on cPanel:
```
your-app-folder/
├── server.js (main server)
├── package.json (dependencies)
├── .env (your config)
├── client/ (frontend files)
├── data/ (JSON backup files)
└── public/ (static assets)
```

Your KARK website will support both JSON file storage (default) and MySQL database storage. Switch between them using the `DB_TYPE` setting in your `.env` file.