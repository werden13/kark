# cPanel Node.js Deployment Fix Guide

## Problem 1: Database Import Error (#1046 - No database selected)

### Solution:
1. **First create your database in cPanel:**
   - Go to cPanel → MySQL Databases
   - Create a new database (e.g., `mysite_kark`)
   - Create a MySQL user and password
   - Add the user to the database with ALL PRIVILEGES

2. **In phpMyAdmin:**
   - Click on your database name in the left sidebar (e.g., `mysite_kark`)
   - THEN click "Import" tab
   - Upload the `kark_complete_database_cpanel_fixed.sql` file

## Problem 2: App Lock Error (Can't acquire lock for app: myapp)

### Solution:
1. **Check Node.js App Setup:**
   - Go to cPanel → Node.js Selector
   - Make sure your app name doesn't conflict with existing apps
   - Use a unique app name like `kark-website-2025`

2. **Fix package.json:**
   - Make sure `package.json` is in your app's root directory
   - Set the correct startup file in cPanel Node.js settings

3. **Common cPanel Node.js Issues:**
   - Ensure your app is using the correct Node.js version
   - Check that all required dependencies are listed in package.json
   - Verify the startup file path is correct

## Environment Configuration for cPanel:
```
DB_TYPE=mysql
DB_HOST=localhost
DB_USER=your_cpanel_mysql_username
DB_PASSWORD=your_cpanel_mysql_password  
DB_NAME=your_cpanel_database_name
DB_PORT=3306
PORT=5000
NODE_ENV=production
SESSION_SECRET=your-secure-random-string-here
```

## Deployment Steps:
1. Upload all files to your cPanel File Manager
2. Set up MySQL database and import SQL file
3. Configure Node.js app in cPanel
4. Update .env with your database credentials
5. Install dependencies through cPanel Node.js interface
6. Start the application

## File Structure for cPanel:
```
your-app-folder/
├── package.json (main dependencies file)
├── server.js (main server file)
├── .env (your environment variables)
├── data/ (JSON storage backup)
├── client/ (frontend files)
└── server/ (backend files)
```