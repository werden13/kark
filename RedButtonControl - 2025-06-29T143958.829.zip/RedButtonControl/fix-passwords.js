import crypto from 'crypto';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';

const scryptAsync = promisify(crypto.scrypt);

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString('hex')}.${salt}`;
}

async function main() {
  try {
    // Read existing users
    const dataDir = path.join(process.cwd(), 'data');
    const usersPath = path.join(dataDir, 'users.json');
    const usersData = await fs.readFile(usersPath, 'utf-8');
    const users = JSON.parse(usersData);
    
    // Hash passwords for all users that have plain text passwords
    let updatedCount = 0;
    for (const user of users) {
      if (!user.password.includes('.')) {
        const plainPassword = user.password;
        user.password = await hashPassword(plainPassword);
        updatedCount++;
      }
    }
    
    // Write updated users back to file
    await fs.writeFile(usersPath, JSON.stringify(users, null, 2));
    
    console.log(`Success! Updated passwords for ${updatedCount} users.`);
  } catch (error) {
    console.error('Error:', error);
  }
}

main();