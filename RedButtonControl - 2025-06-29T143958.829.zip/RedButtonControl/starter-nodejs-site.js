/**
 * KARK Website - Node.js Starter File
 * This file provides a basic setup to run the KARK website
 * 
 * Prerequisites:
 * - Node.js v18+ installed
 * - npm or yarn package manager
 * 
 * Setup Instructions:
 * 1. Copy this file to your project root
 * 2. Run: npm install
 * 3. Create a .env file with your configuration
 * 4. Run: npm run dev (development) or npm start (production)
 */

// Import required modules
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import session from 'express-session';
import memorystore from 'memorystore';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Load environment variables
dotenv.config();

// Get directory paths for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express app
const app = express();
const PORT = process.env.PORT || 5000;

// Create memory store for sessions
const MemoryStore = memorystore(session);

// =====================================================
// MIDDLEWARE SETUP
// =====================================================

// Basic security headers
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      imgSrc: ["'self'", "data:", "https:", "http:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
    },
  },
}));

// CORS configuration
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true
}));

// Body parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  store: new MemoryStore({
    checkPeriod: 86400000 // prune expired entries every 24h
  }),
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days
  }
}));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// =====================================================
// BASIC ROUTES
// =====================================================

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    storageType: process.env.DB_TYPE || 'json'
  });
});

// Basic info endpoint
app.get('/api/info', (req, res) => {
  res.json({
    name: 'KARK Website API',
    version: '1.0.0',
    description: 'Kurtarma ve Arama Derneği Website API'
  });
});

// Sample protected route
app.get('/api/admin/dashboard', (req, res) => {
  // Check if user is authenticated (implement your auth logic)
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  res.json({
    message: 'Welcome to admin dashboard',
    user: req.session.user
  });
});

// =====================================================
// DATABASE/STORAGE CONFIGURATION
// =====================================================

// Check storage type from environment
const storageType = process.env.DB_TYPE || 'json';

if (storageType === 'mysql') {
  console.log('📦 Using MySQL database storage');
  console.log('   Host:', process.env.MYSQL_HOST || 'localhost');
  console.log('   Database:', process.env.MYSQL_DATABASE || 'not configured');
} else {
  console.log('📁 Using JSON file storage');
  console.log('   Data directory: ./data/');
}

// =====================================================
// SAMPLE DATA STRUCTURE
// =====================================================

// Sample in-memory data (replace with database/file operations)
let sampleData = {
  users: [
    {
      id: 1,
      username: 'supermanager',
      // Password: admin123 (bcrypt hashed)
      password: '$2b$10$Yd9ipAccHnu.ezzIDhPk2.byPUq590FDQIq8fmvQrq7zmyUBLIQ/2',
      email: 'superadmin@kark.org',
      role: 'major_admin'
    }
  ],
  settings: {
    siteName: 'KARK - Kurtarma ve Arama Derneği',
    contactEmail: 'info@kark.org',
    contactPhone: '+90 555 123 4567'
  }
};

// =====================================================
// ERROR HANDLING
// =====================================================

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' 
      ? 'Internal server error' 
      : err.message
  });
});

// =====================================================
// SERVER STARTUP
// =====================================================

app.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔════════════════════════════════════════════╗
║         KARK Website Server Started        ║
╚════════════════════════════════════════════╝

🚀 Server running on http://localhost:${PORT}
📝 Environment: ${process.env.NODE_ENV || 'development'}
💾 Storage Type: ${storageType}
🔐 Session Secret: ${process.env.SESSION_SECRET ? 'Configured' : 'Using default (CHANGE THIS!)'}

Available endpoints:
- GET  /api/health - Health check
- GET  /api/info - API information
- GET  /api/admin/dashboard - Protected admin route

To get started:
1. Create a .env file with your configuration
2. Set up your database (if using MySQL)
3. Import the provided SQL files
4. Start building your routes!
  `);
});

// =====================================================
// GRACEFUL SHUTDOWN
// =====================================================

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  process.exit(0);
});

// Export app for testing
export default app;